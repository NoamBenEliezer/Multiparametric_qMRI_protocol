clear all
clc

MultThr_num = 2;

All_data_path='.../Segmentations_FS/Brain_Atlas';

%% Run all volunteers
dir_list=dir(All_data_path);
count=0;
for vol_idx=1:length(dir_list)
if dir_list(vol_idx).name(1)=='V'
    count=count+1;
        Volunteer_list{count}=dir_list(vol_idx).name;
end
end


for vol_idx=1:1:length(Volunteer_list)
vol_ID=Volunteer_list{vol_idx};
% vol_dir= dir([All_data_path filesep vol_ID]);
Cur_Sbj_dir = [All_data_path filesep vol_ID]; % % directory of patient (where all his scans are)

% T2 star
if ~exist([Cur_Sbj_dir filesep 'temp' filesep 'T2s_seg.mat'])
Register_FS_BA_T2s(Cur_Sbj_dir, vol_ID); %T2 star - qT2s
end

% QSM
if ~exist([Cur_Sbj_dir filesep 'temp' filesep 'QSM_seg_new.mat'])
Register_FS_BA_QSM(Cur_Sbj_dir, vol_ID); %T2 star - qT2s
end

% ihMT
if ~exist([Cur_Sbj_dir filesep 'temp' filesep 'ihMTR_seg.mat'])
Register_FS_BA_ihMT(Cur_Sbj_dir, vol_ID); %T2 star - qT2s
end

% T2
if ~exist([Cur_Sbj_dir filesep 'temp' filesep 'qT2_seg.mat'])
Register_FS_BA_qT2(Cur_Sbj_dir, vol_ID); %T2 star - qT2s
end


end





