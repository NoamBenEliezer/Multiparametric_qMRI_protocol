
clear all; clc

addpath(genpath('.../Segmentations_FS'));

Data_dir='.../Segmentations_FS/rawdata/MP2RAGE';

MultThr_num = 8; % parfor=2, for =8



subjects_dir=dir(Data_dir);

subj_count=0;
for i=1:length (subjects_dir)
    
    if subjects_dir(i).name(1)=='.'
        continue;
    end
    subj_count=subj_count+1;
    subjects_list{1, subj_count}=subjects_dir(i).name;
    scan_dir=dir([Data_dir filesep subjects_list{1, subj_count}]);
    
    %     for j=1:length (scan_dir)
    %         if scan_dir(j).name(1)=='3' || scan_dir(j).name(1)=='4'
    %             subjects_list{2, subj_count}=scan_dir(j).name;
    %         end
    %     end
    
    for j=1:length (scan_dir)
        if scan_dir(j).name(1)=='.'
            continue;
        elseif strfind (scan_dir(j).name,'rage')
            subjects_list{2, subj_count}=scan_dir(j).name;
        end
    end
    
    DCM_dir=dir([Data_dir filesep subjects_list{1, subj_count} filesep subjects_list{2, subj_count}]);
    for k=1:3 
        if DCM_dir(k).name(1)=='0'
            subjects_list{3, subj_count}=DCM_dir(k).name(1:end-4);
        end
    end
    
end


% parfor SubjectIdx=1:length(subjects_list)
   for SubjectIdx=1:length(subjects_list)
    Cur_Sbj_dir= [Data_dir filesep subjects_list{1, SubjectIdx}];

       if exist ([Cur_Sbj_dir filesep '00_FSseg/mri/orig/001.mgz'])
           continue;
       end
       
    Loc_T1w_dir = [subjects_list{2, SubjectIdx} filesep subjects_list{3, SubjectIdx}];
    
%     if length (dir(Cur_Sbj_dir))<4
        Segment_BrainAtlas(Cur_Sbj_dir, Loc_T1w_dir, MultThr_num);
%     end
    
end
