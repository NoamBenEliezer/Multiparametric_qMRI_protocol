%% Examplary script 2: command is more clear

%% freesurfer commands:
% % recon-all -s <output folder name> -i <input dicom file name>.dcm -openmp <# of threads> -all
% % mri_convert -it siemens_dicom -ot mgz <input dicom file name>.dcm <output folder name>
% % bbregister --s <segmentation folder> --mov <mri_convert's output folder name>.mgz   --reg <output freesurfer registration file>.dat   --init-header --t2
% % mri_vol2vol --mov <mri_convert's output folder name>.mgz --targ <segmentation folder>/mri/aparc+aseg.mgz --interp nearest --o <output registered scan>.mgz --reg <output freesurfer registration file>.dat --no-save-reg

function []=Register_FS_BA_QSM(Cur_Sbj_dir, vol_ID)


%% Script

% % recon-all
Loc_Seg_flr = '00_FSseg';
% MultThr_num = 8;

% % Rigid registration

tmp_flr = 'temp';
% Cur_Sbj_dir = '/home/noambe/Public/Segmentations_FS/Brain_Atlas/V002'; % % directory of patient (where all his scans are)

Example_DCM=dir([Cur_Sbj_dir filesep 'QSM/Mag_DCM_Echo3']);
Example_DCM=Example_DCM(10).name;
Loc_QSM_dcm_dir = [Cur_Sbj_dir filesep 'QSM/Mag_DCM_Echo3' filesep Example_DCM]; % % original T1w .mgz file
Loc_QSM_mgz_dir = [tmp_flr filesep 'Mag_mgz_Echo3.mgz'];
Loc_LUT_mgz_dir = [Loc_Seg_flr filesep 'mri/aparc+aseg.mgz'];
Loc_QSM_RegMat_dir = [tmp_flr filesep 'QSM_2_Seg.dat']; % % intermediate registration transform file
Inv_reg_flg = 1;
Loc_QSM_Reg_dir = [tmp_flr filesep 'QSM_segments.mgz']; % % output .mgz file after registration

% % Create temporary folder for output
tmp_dir = [Cur_Sbj_dir filesep tmp_flr];
mkdir(tmp_dir)

% % Command that calls scripts
FS_shell_cmd = [ ...
    'export FREESURFER_HOME=/usr/local/freesurfer'               newline... % % set freesurfer commands directories
    'source $FREESURFER_HOME/SetUpFreeSurfer.sh'                 newline... % % run a script that configures freesurfer
    'export SUBJECTS_DIR=' Cur_Sbj_dir                           newline... % % set directory of current patient
    'cd $SUBJECTS_DIR'                                           newline... % % change directory to current subject
    'mri_convert'                                                       ...
                ' -it siemens_dicom'                                    ...
                ' -ot mgz '                                             ...
                Loc_QSM_dcm_dir ' ' Loc_QSM_mgz_dir                  newline... % % convert DICOM files to .mgz file
    'bbregister'                                                        ...
                ' --s ' Loc_Seg_flr                                     ...
                ' --mov ' Loc_QSM_mgz_dir                                   ...
                '       --reg ' Loc_QSM_RegMat_dir                      ...
                '       --init-header --t2'                      newline... % % calculate registratiom
    'mri_vol2vol'                                                       ...
                ' --mov ' Loc_QSM_mgz_dir                               ... % % perform registration
                '     --targ ' Loc_Seg_flr '/mri/aparc+aseg.mgz'        ...
                ' --interp nearest'                                     ...
                '     --o ' Loc_QSM_Reg_dir                             ...
                '     --reg ' Loc_QSM_RegMat_dir                        ... 
                '     --no-save-reg'                                    ...
    ];
if Inv_reg_flg
    FS_shell_cmd = [FS_shell_cmd ' --inv' newline];
else
    FS_shell_cmd = [FS_shell_cmd newline];
end
                        
%% execute & return exit status

[stat, cmdout] = system(FS_shell_cmd);
% disp(stat) % % 0 = success, ~0 = Error
% disp(cmdout); % % Command output

%% load .mgz

% % % Add freesurfer matlab functions to path
QSM_seg_dir=[Cur_Sbj_dir filesep Loc_QSM_Reg_dir];
FS_mtl_Fld  = '.../freesurfer_MATLAB_scripts';
addpath(FS_mtl_Fld)
QSM_seg= load_mgh(QSM_seg_dir);
QSM_seg_new=zeros(size(QSM_seg));
for slc_idx=1:size(QSM_seg,3)
QSM_seg_new(:,:,slc_idx)= fliplr(squeeze(QSM_seg(:,:,slc_idx)));
end

save ([Cur_Sbj_dir filesep 'temp' filesep 'QSM_seg_new'],'QSM_seg_new')

