%% Examplary script 2: command is more clear

function []=Register_FS_BA_T2s(Cur_Sbj_dir, vol_ID)
%% Script

% % recon-all
Loc_Seg_flr = '00_FSseg';
% MultThr_num = 8;

% % Rigid registration

tmp_flr = 'temp';
% Cur_Sbj_dir = '/home/noambe/Public/Segmentations_FS/Brain_Atlas/V002'; % % directory of patient (where all his scans are)
Loc_T2s_mgz_dir = [tmp_flr filesep 'T2s.mgz']; % % intermediate .mgz file
% Loc_qT2_mgz_dir = '';
% Loc_T1w_dir = 'tfl3d1_16ns/t1_mprage_sag_p2_iso_MPR_tra/1.3.12.2.1107.5.2.43.166079.2021012210165880187799627.dcm'; % % input dicom file
Loc_T2s_dir = sprintf('T2_star/T2s_map_%s_1.dcm',vol_ID);
% Loc_qT2_dir = '';
Loc_T2s_RegMat_dir = [tmp_flr filesep 'T1w_2_T2s.dat']; % % intermediate registration transform file
% Loc_qT2_RegMat_dir = [tmp_flr filesep 'qT2_2_T1w.dat'];
Inv_reg_flg = 1;
Loc_T2s_Reg_dir = [tmp_flr filesep 'T2s_segments.mgz']; % % output .mgz file after registration
% Loc_qT2_Reg_dir = [tmp_flr filesep 'qT2_Reg.mgz'];

% % Create temporary folder for output
tmp_dir = [Cur_Sbj_dir filesep tmp_flr];
if ~ exist (tmp_dir)
mkdir(tmp_dir)
end

% % Command that calls scripts
FS_shell_cmd = [ ...
    'export FREESURFER_HOME=/usr/local/freesurfer'               newline... % % set freesurfer commands directories
    'source $FREESURFER_HOME/SetUpFreeSurfer.sh'                 newline... % % run a script that configures freesurfer
    'export SUBJECTS_DIR=' Cur_Sbj_dir                           newline... % % set directory of current patient
    'cd $SUBJECTS_DIR'                                           newline... % % change directory to current subject
    'mri_convert'                                                       ...
                ' -it siemens_dicom'                                    ...
                ' -ot mgz '                                             ...
                Loc_T2s_dir ' ' Loc_T2s_mgz_dir                  newline... % % convert DICOM files to .mgz file
    'bbregister'                                                        ...
                ' --s ' Loc_Seg_flr                                     ...
                ' --mov ' Loc_T2s_mgz_dir                               ...
                '       --reg ' Loc_T2s_RegMat_dir                      ...
                '       --init-header --t2'                      newline... % % calculate registratiom
    'mri_vol2vol'                                                       ...
                ' --mov ' Loc_T2s_mgz_dir                               ... % % perform registration
                '     --targ ' Loc_Seg_flr '/mri/aparc+aseg.mgz'        ...
                ' --interp nearest'                                     ...
                '     --o ' Loc_T2s_Reg_dir                             ...
                '     --reg ' Loc_T2s_RegMat_dir                        ... 
                '     --no-save-reg'                                    ...
    ];
if Inv_reg_flg
    FS_shell_cmd = [FS_shell_cmd ' --inv' newline];
else
    FS_shell_cmd = [FS_shell_cmd newline];
end
                        
%% execute & return exit status

[stat, cmdout] = system(FS_shell_cmd);
% disp(stat) % % 0 = success, ~0 = Error
% disp(cmdout); % % Command output

%% load .mgz

% % % Add freesurfer matlab functions to path

T2s_seg_dir=[Cur_Sbj_dir filesep Loc_T2s_Reg_dir];
FS_mtl_Fld  = '.../freesurfer_MATLAB_scripts';
addpath(FS_mtl_Fld)
T2s_seg= load_mgh(T2s_seg_dir);

save ([Cur_Sbj_dir filesep 'temp' filesep 'T2s_seg'],'T2s_seg')
