%% Examplary script 2: command is more clear

function []=Register_FS_BA_ihMT(Cur_Sbj_dir, vol_ID); %T2 star - qT2s


%% Script

% % recon-all
Loc_Seg_flr = '00_FSseg';
% MultThr_num = 8;

% % Rigid registration

tmp_flr = 'temp';
% Cur_Sbj_dir = '/home/noambe/Public/Segmentations_FS/Brain_Atlas/V002'; % % directory of patient (where all his scans are)
Loc_ihmtr_nii_dir = 'ihMT/out_ihMTR.nii'; % % original ihmtr .nii file
Loc_LUT_mgz_dir = [Loc_Seg_flr filesep '/mri/aparc+aseg.mgz'];
Loc_ihmtr_RegMat_dir = [tmp_flr filesep 'ihmtr_2_seg.dat']; % % intermediate registration transform file
Inv_reg_flg = 1;
Loc_ihmtr_Reg_dir = [tmp_flr filesep 'ihmtr_segments.mgz']; % % output .mgz file after registration

% % Create temporary folder for output
tmp_dir = [Cur_Sbj_dir filesep tmp_flr];
mkdir(tmp_dir)

% % Command that calls scripts
FS_shell_cmd = [ ...
    'export FREESURFER_HOME=/usr/local/freesurfer'               newline... % % set freesurfer commands directories
    'source $FREESURFER_HOME/SetUpFreeSurfer.sh'                 newline... % % run a script that configures freesurfer
    'export SUBJECTS_DIR=' Cur_Sbj_dir                           newline... % % set directory of current patient
    'cd $SUBJECTS_DIR'                                           newline... % % change directory to current subject
    'bbregister'                                                        ...
                ' --s ' Loc_Seg_flr                                     ...
                ' --mov ' Loc_ihmtr_nii_dir                                   ...
                '       --reg ' Loc_ihmtr_RegMat_dir                      ...
                '       --init-header --t1'                      newline... % % calculate registratiom
    'mri_vol2vol'                                                       ...
                ' --mov ' Loc_ihmtr_nii_dir                               ... % % perform registration
                '     --targ ' Loc_Seg_flr '/mri/aparc+aseg.mgz'        ...
                ' --interp nearest'                                     ...
                '     --o ' Loc_ihmtr_Reg_dir                             ...
                '     --reg ' Loc_ihmtr_RegMat_dir                        ... 
                '     --no-save-reg'                                    ...
    ];
if Inv_reg_flg
    FS_shell_cmd = [FS_shell_cmd ' --inv' newline];
else
    FS_shell_cmd = [FS_shell_cmd newline];
end
                        
%% execute & return exit status

[stat, cmdout] = system(FS_shell_cmd);
% disp(stat) % % 0 = success, ~0 = Error
% disp(cmdout); % % Command output

%% load .mgz

ihMTR_seg_dir=[Cur_Sbj_dir filesep Loc_ihmtr_Reg_dir];
FS_mtl_Fld  = '.../freesurfer_MATLAB_scripts';
addpath(FS_mtl_Fld)
ihMTR_seg= load_mgh(ihMTR_seg_dir);

save ([Cur_Sbj_dir filesep 'temp' filesep 'ihMTR_seg'],'ihMTR_seg')