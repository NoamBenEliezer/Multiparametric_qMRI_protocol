%% Examplary script 2: command is more clear

function []=Register_FS_BA_qT2(Cur_Sbj_dir, vol_ID)
%% Script

% % recon-all
Loc_Seg_flr = '00_FSseg';
% MultThr_num = 8;

% % Rigid registration

tmp_flr = 'temp';
% Cur_Sbj_dir = '/home/noambe/Public/Segmentations_FS/Brain_Atlas/V002'; % % directory of patient (where all his scans are)
Loc_qT2_mgz_dir = [tmp_flr filesep 'qT2.mgz']; % % intermediate .mgz file
% sprintf('T2map_den_%s_sl_%d.dcm',vol_ID,dcm_idx)
Loc_qT2_dir = sprintf('qT2/T2map_den_%s_sl_1.dcm',vol_ID);
Loc_qT2_RegMat_dir = [tmp_flr filesep 'T1w_2_qT2.dat']; % % intermediate registration transform file
Inv_reg_flg = 1;
Loc_qT2_Reg_dir = [tmp_flr filesep 'qT2_segments.mgz']; % % output .mgz file after registration

% % Create temporary folder for output
tmp_dir = [Cur_Sbj_dir filesep tmp_flr];
if ~ exist (tmp_dir)
mkdir(tmp_dir)
end

% % Command that calls scripts
FS_shell_cmd = [ ...
    'export FREESURFER_HOME=/usr/local/freesurfer'               newline... % % set freesurfer commands directories
    'source $FREESURFER_HOME/SetUpFreeSurfer.sh'                 newline... % % run a script that configures freesurfer
    'export SUBJECTS_DIR=' Cur_Sbj_dir                           newline... % % set directory of current patient
    'cd $SUBJECTS_DIR'                                           newline... % % change directory to current subject
    'mri_convert'                                                       ...
                ' -it siemens_dicom'                                    ...
                ' -ot mgz '                                             ...
                Loc_qT2_dir ' ' Loc_qT2_mgz_dir                  newline... % % convert DICOM files to .mgz file
    'bbregister'                                                        ...
                ' --s ' Loc_Seg_flr                                     ...
                ' --mov ' Loc_qT2_mgz_dir                               ...
                '       --reg ' Loc_qT2_RegMat_dir                      ...
                '       --init-header --t2'                      newline... % % calculate registratiom
    'mri_vol2vol'                                                       ...
                ' --mov ' Loc_qT2_mgz_dir                               ... % % perform registration
                '     --targ ' Loc_Seg_flr '/mri/aparc+aseg.mgz'        ...
                ' --interp nearest'                                     ...
                '     --o ' Loc_qT2_Reg_dir                             ...
                '     --reg ' Loc_qT2_RegMat_dir                        ... 
                '     --no-save-reg'                                    ...
    ];
if Inv_reg_flg
    FS_shell_cmd = [FS_shell_cmd ' --inv' newline];
else
    FS_shell_cmd = [FS_shell_cmd newline];
end
                        
%% execute & return exit status

[stat, cmdout] = system(FS_shell_cmd);
% disp(stat) % % 0 = success, ~0 = Error
% disp(cmdout); % % Command output

%% load .mgz

% % % Add freesurfer matlab functions to path

qT2_seg_dir=[Cur_Sbj_dir filesep Loc_qT2_Reg_dir];
FS_mtl_Fld  = '.../freesurfer_MATLAB_scripts';
addpath(FS_mtl_Fld)
qT2_seg= load_mgh(qT2_seg_dir);

save ([Cur_Sbj_dir filesep 'temp' filesep 'qT2_seg'],'qT2_seg')
