function []=Segment_BrainAtlas(Cur_Sbj_dir, Loc_T1w_dir, MultThr_num)



%% Script

% % recon-all
Loc_Seg_flr = '00_FSseg';

% % Create temporary folder for output
tmp_flr = 'temp';
tmp_dir = [Cur_Sbj_dir filesep tmp_flr];
mkdir(tmp_dir)

%% Only Recon
FS_shell_cmd = [ ...
    'export FREESURFER_HOME=/usr/local/freesurfer'               newline... % % set freesurfer commands directories
    'source $FREESURFER_HOME/SetUpFreeSurfer.sh'                 newline... % % run a script that configures freesurfer
    'export SUBJECTS_DIR=' Cur_Sbj_dir                           newline... % % set directory of current patient
    'cd $SUBJECTS_DIR'                                           newline... % % change directory to current subject
    'recon-all'                                                         ...
                ' -s ' Loc_Seg_flr                                      ...
                ' -i ' Loc_T1w_dir '.dcm'                               ...
                ' -openmp ' num2str(MultThr_num)                        ... 
                ' -all'                                          newline... % % perform segmentation
     ];


[stat, cmdout] = system(FS_shell_cmd);


%% load .mgz

% % % Add freesurfer matlab functions to path
% FS_mtl_Fld  = '.../freesurfer_MATLAB_scripts';
% addpath(FS_mtl_Fld)
