function Y = CreateMask(X, mask_th)

mask_im   = X;
th_SE = mask_th*max(mask_im(:));
mask = ones(size(squeeze(mask_im(:,:,1))));
mask(mask_im(:,:,1) < th_SE) = 0;
Y = mask;
