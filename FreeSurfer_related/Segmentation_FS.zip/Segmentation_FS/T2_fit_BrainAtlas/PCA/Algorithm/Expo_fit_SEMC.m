
function [T2_SEMC, T2_SEMC_err, nEchoesMat_SEMC_expFit] = Expo_fit_SEMC(rep_im_SEMC, im_SEMC, TEs_SEMC, fit_sig_th, ...
                                                                        min_N_echoes, T2minHardLimit, T2maxHardLimit)

zr2         = zeros(size(rep_im_SEMC,1),size(rep_im_SEMC,2));
T2_SEMC     = zr2;
T2_SEMC_err = zr2;
nEchoesMat_SEMC_expFit = zr2;

% fh=figure;
for dx = 1:size(im_SEMC,1)
	parfor dy = 1:size(im_SEMC,2)
% 	for dy = 1:size(im_SEMC,2)
		if (rep_im_SEMC(dx,dy) == 0)
			continue;
		end;
		% extract current vector
		vec = transpose(double(squeeze(im_SEMC(dx,dy,:))));
		t   = TEs_SEMC;
		
% 		if (dx==99 && dy==94)
% 			if (exist('fh','var')), figure(fh); else, figure; end; ;plot(vec,'.-'); pause(0.2);
% 		end;
		
		% Truncate the echo time series below a certain threshhold
		if (fit_sig_th ~= 0)
			cur_threshold = vec(1)*fit_sig_th;
			for cur_N_echoes = 1:length(vec)
				if (vec(cur_N_echoes) <= cur_threshold)
					break;
				end;
			end;
			loc = 1:max(cur_N_echoes,min_N_echoes);
			
			vec = vec(loc);
			t   = t(loc);
		end;
		nEchoesMat_SEMC_expFit(dx,dy) = length(vec);
		
		% do the fit
		[a_SEMC, s_SEMC] = polyfit(t,log(vec), 1);
		
		% save the fitting values and errors
		if (sum(isnan(a_SEMC)) > 0) || ((-1/a_SEMC(1)) < T2minHardLimit) || ((-1/a_SEMC(1)) > T2maxHardLimit)
			cur_T2_SEMC     = 0;
		else
			a                = a_SEMC(1);
			cur_T2_SEMC     = -1/a;
		end;
		T2_SEMC(dx,dy) = cur_T2_SEMC;
	end;
end;
