function UD = GUI_Var_Init(handles)

UD = get(handles.figure1,'UserData');
if (isempty(UD))
	clear UD;
end;

default_T2weightPD_TEms = 0;  % [ms] e.g. 20e-3
default_mask_th_T       = 0.02;
default_interpF         = 2;

set(handles.EMC_DB_fn      , 'String', []);
% set(handles.SEMC_Data_Dir_T, 'String', []);
set(handles.DICOM_Table    , 'Data'  , []);
set(handles.ActiveSlice    , 'Value' , 1 );

set(handles.mask_th_T       ,'String', num2str(default_mask_th_T));
set(handles.mask_th_S       ,'Value' ,         default_mask_th_T );
set(handles.Interp_T        ,'String', num2str(default_interpF));
set(handles.NROI_T          ,'String', num2str(0));
set(handles.Start_FIT       ,'Enable', 'on');
set(handles.Start_FIT       ,'String', 'Start Fitting');
set(handles.Apply_Plot      ,'Enable', 'on');

set(handles.fit_B1_flag_B   ,'String','OFF');
set(handles.fit_B1_flag_B   ,'Value' , 0.00 );

set(handles.exp_fit_SEMC_B  ,'String', 'OFF');
set(handles.exp_fit_SEMC_B  ,'Value' , 0    );
set(handles.exp_fit_SEMC_B  ,'Value' , 0    );

set(handles.T2weightPD_TEms ,'String', num2str(default_T2weightPD_TEms*1e+3));
set(handles.T2weightPD_TEms ,'Value' ,         default_T2weightPD_TEms );

UD.active_sl       = 1;
UD.PD_caxis_Slider = 100;
UD.T2_caxis_Slider = 100;
UD.zoomF           = 1;
UD.axis            = [];
UD.T2_SEMC_fit2sim = [];
UD.PD_SEMC_EMC     = [];
UD.mask_SEMC       = [];
UD.T2_caxis_base   = [0    200];
UD.PD_caxis_base   = [0.05 0.8];
UD.mask_th         = default_mask_th_T;
UD.interpF         = default_interpF;
UD.interp_method   = 'linear';
UD.T2weightPD_TEms = default_T2weightPD_TEms;
UD.exp_fit_SEMC    = 0;
UD.fit_B1_flag     = 0;

% Clear maps from EMC results structure.
% Leave ROIs ... just to save some time in case user wants to re-use ROIs.
% if (isfield(UD,'nSl') && (UD.nSl > 0))
% 	for idx = 1:UD.nSl
% 		UD.EMC_results(idx).Original_image            = [];
% 		UD.EMC_results(idx).mask_SEMC                 = [];
% 
% 		UD.EMC_results(idx).B1map_SEMC_EMC            = [];
% 		UD.EMC_results(idx).B1map_SEMC_EMC_masked     = [];
% 		UD.EMC_results(idx).T2map_SEMC_EMC            = [];
% 		UD.EMC_results(idx).T2map_SEMC_EMC_masked     = [];
% 		UD.EMC_results(idx).PDmap_SEMC_EMC            = [];
% 		UD.EMC_results(idx).PDmap_SEMC_EMC_masked     = [];
% 
% 		UD.EMC_results(idx).T2map_SEMC_monoexp        = [];
% 		UD.EMC_results(idx).T2map_SEMC_monoexp_masked = [];
% 		UD.EMC_results(idx).PDmap_SEMC_monoexp        = [];
% 		UD.EMC_results(idx).PDmap_SEMC_monoexp_masked = [];
% 	end;
% end;

set(handles.figure1,'UserData',UD);

return;


