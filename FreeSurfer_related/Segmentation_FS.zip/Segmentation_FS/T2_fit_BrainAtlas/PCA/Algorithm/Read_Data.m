
function [f_info,info1,im_SEMC,im_SEMC_orig] = Read_Data(SEMCDataDir)
% -------------------------------------------------------------
%  Read data ... smooth ... crop ... resize ... etc
% -------------------------------------------------------------
clear im_SEMC im_SE;
fname = dir(SEMCDataDir);

for k = length(fname):-1:1
    % remove folders
    if fname(k).isdir
        fname(k) = [ ];
        continue
    end

    % remove folders starting with .
    if fname(k).name(1) == '.'
        fname(k) = [ ];
    end
end
% fname.name
f_info = dicominfo([SEMCDataDir,'/',fname(1).name]);
info1 = SiemensInfo(f_info);
if info1.lContrasts ~= (length(fname)),
    declare_substage('lContrast ERROR!!!');
else
    declare_substage(['Reading ',num2str(info1.lContrasts),' echoes']);
end,

parfor idx = 1:length(fname)
    % fname(idx)
    im_SEMC(:,:,idx) = double(dicomread([SEMCDataDir,'/',fname(idx).name]));
end;
im_SEMC_orig = im_SEMC;
