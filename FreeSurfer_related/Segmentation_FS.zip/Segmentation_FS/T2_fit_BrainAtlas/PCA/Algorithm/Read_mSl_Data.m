
function [dcm_info,dcm_info_parsed,im_SEMC_mSl,slices_info] = Read_mSl_Data(SEMCDataDir)

% -------------------------------------------------------------
%  Read data ... smooth ... crop ... resize ... etc
% -------------------------------------------------------------
fname = dir(SEMCDataDir);

dcm_fnames    = {};
dat_fnames    = {};
Bruker_fnames = {};
for idx = 1:length(fname)
	% skip folders and files starting with '.'
	if (fname(idx).isdir) || (fname(idx).name(1) == '.') || endsWith(fname(idx).name,'ini')
		continue;
	end;
	
	ftype = lower(fname(idx).name(end-2:end));
	fn    = fname(idx).name;
	
	% Collect DICOM files
	if (strcmpi(ftype,'dcm')) || ...
	   (strcmpi(ftype,'ima')) || ...
	   (strcmpi(ftype,'img')) || ...
	   (isdicomfile([SEMCDataDir filesep fn]))
		dcm_fnames{end+1} = fn;
		continue;
	end;

	% Check for raw dat files
	if (strcmpi(ftype,'dat'))
		dat_fnames{end+1} = fn;
		continue;
	end;
end;

reload_dcm_flag = 0;

% Check if we need to reconstruct DICOM images manually from raw data file
if (length(dat_fnames) > 1)
	error('Load Error: too many raw data files (%1.0f)',length(dat_fnames));
end;

% Perform the reconstruction
if (length(dat_fnames) == 1) && (length(dcm_fnames) == 1)
	representative_dcm_fn = dcm_fnames{1};
	emc_reconstruct_dicoms_from_raw_data(SEMCDataDir,dat_fnames{1},representative_dcm_fn);
	reload_dcm_flag = 1;
	
% Reconstruction already performed - just load the DICOMs
elseif (length(dat_fnames) == 1)
	reload_dcm_flag = 1;
end;

if (reload_dcm_flag)
	% Re-collect the list of DICOMs
	fname = dir(SEMCDataDir);

	dcm_fnames = {};
	for idx = 1:length(fname)
		% Load only DICOMs with a prefix of 'Reconstructed_dcm'
		if strfind(fname(idx).name,'Reconstructed_dcm')
			dcm_fnames{end+1} = fname(idx).name;
		end;
	end;
end;

if (isempty(dcm_fnames))
	[dcm_info,dcm_info_parsed,im_SEMC_mSl,slices_info] = deal([]);
	uiwait(msgbox('Error: No files found in DICOM directory'));
	return;
end;

dcm_info        = dicominfo([SEMCDataDir filesep dcm_fnames{1}]);
dcm_info_parsed = SiemensInfo(dcm_info);
nSl             = ceil((length(dcm_fnames))/dcm_info_parsed.lContrasts);
nEc             = dcm_info_parsed.lContrasts;

if (mod((length(dcm_fnames)),dcm_info_parsed.lContrasts) ~= 0)
    uiwait(msgbox(sprintf('Error: mismatch between number of echoes (%1.0f) and number of files (%1.0f)',dcm_info_parsed.lContrasts, length(dcm_fnames))));
	error('Exiting...');
else
    declare_substage(['Reading ',num2str(dcm_info_parsed.lContrasts),' echoes (# of slices = ' num2str(round((length(dcm_fnames))/dcm_info_parsed.lContrasts)) ')']);
end;


% parfor idx = 1:length(dcm_fnames)
for idx = 1:length(dcm_fnames)
	im_SEMC(:,:,idx)        = double(dicomread([SEMCDataDir,'/',dcm_fnames{idx}])); %#ok<*AGROW>
	tmp_info(idx)           = dicominfo([SEMCDataDir,'/',dcm_fnames{idx}]);
	SeriesNumber_arr(idx)   = tmp_info(idx).SeriesNumber;
	InstanceNumber_arr(idx) = tmp_info(idx).InstanceNumber;
	sl_loc_arr(idx)         = tmp_info(idx).SliceLocation;
	ec_num_arr(idx)         = tmp_info(idx).EchoNumber;                             %#ok<*NASGU>
end;
ImageOrient   = transpose(tmp_info(1).ImageOrientationPatient);
ImagePosition = transpose(tmp_info(1).ImagePositionPatient);
PEdir         =           tmp_info(1).InPlanePhaseEncodingDirection;

sl_loc = unique(sl_loc_arr);
sl_loc = sort(sl_loc);

im_SEMC_mSl = zeros([size(im_SEMC,1),size(im_SEMC,2),nSl,nEc]);
for sl_idx = 1:length(sl_loc)
	% Extract current slice
	cur_slice_loc             = sl_loc(sl_idx);
	tmp_slc_locs              = find(sl_loc_arr == cur_slice_loc);
	tmp_im_SEMC_per_slc       = im_SEMC(:,:,tmp_slc_locs);

	% Extract corresponding set of echo times and series number
	tmp_series_num_per_slc    = SeriesNumber_arr(tmp_slc_locs);
	SeriesNumber(sl_idx)      = tmp_series_num_per_slc(1);
	tmp_ec                    = ec_num_arr(tmp_slc_locs);
	
	% Sort echo times
	[~,tmp_ec_idx]            = sort(tmp_ec);
	tmp_im_SEMC_per_slc       = tmp_im_SEMC_per_slc(:,:,tmp_ec_idx);
	im_SEMC_mSl(:,:,sl_idx,:) = tmp_im_SEMC_per_slc;
end;

% % % % % 
% % % % % [InstanceNumber_arr,sl_order_idxs] = sort(InstanceNumber_arr);
% % % % % InstanceNumber                     = InstanceNumber_arr(1:nSl);
% % % % % SeriesNumber_arr                   = SeriesNumber_arr(sl_order_idxs);
% % % % % SeriesNumber                       = SeriesNumber_arr(1:nSl);
% % % % % sl_loc_arr                         = sl_loc_arr(sl_order_idxs);
% % % % % sl_loc                             = sl_loc_arr(1:nSl);
% % % % % 
% % % % % [~,sl_order_idxs]                  = sort(sl_loc_arr);
% % % % % im_SEMC_by_slice_order             = im_SEMC(:,:,sl_order_idxs);
% % % % % ec_num_arr_by_slice_order          = ec_num_arr(sl_order_idxs);

% ec_num_arr                       = ec_num_arr(sl_order_idxs);
% ec_num_arr                       = ec_num_arr(1:nSl);

% >>> OBSOLETE
% [~,sl_order_idxs]         = sort(sl_loc_arr);
% im_SEMC_by_slice_order    = im_SEMC(:,:,sl_order_idxs);
% ec_num_arr_by_slice_order = ec_num_arr(sl_order_idxs);
% slices_loc                = sort(unique(sl_loc_arr));
% <<<

slices_info.SeriesNumber   = SeriesNumber;
% slices_info.InstanceNumber = InstanceNumber;
slices_info.ImageOrient    = ImageOrient;
slices_info.ImagePosition  = ImagePosition;
slices_info.PEdir          = PEdir;
slices_info.slices_loc     = sl_loc;

% % % % % im_SEMC_mSl = zeros([size(im_SEMC,1),size(im_SEMC,2),nSl,nEc]);
% % % % % for sl_idx = 1:nSl
% % % % % 	for ec_idx = 1:nEc
% % % % % 		im_SEMC_mSl(:,:,sl_idx,ec_num_arr_by_slice_order((sl_idx-1)*nEc + ec_idx)) = im_SEMC_by_slice_order(:,:,(sl_idx-1)*nEc + ec_idx);
% % % % % 	end;
% % % % % end;

% im_SEMC_mSl_orig = im_SEMC_mSl;

return;


% figure;
% for idx = 1:nSl
% 	imagesc(squeeze(im_SEMC_mSl(:,:,idx,2))); axis image; cg;  % ca=caxis; caxis(ca/1.3);
% 	pause(0.7);
% end;
% 
% figure;
% for idx = 1:nEc
% 	imagesc(squeeze(im_SEMC_mSl(:,:,3,idx))); axis image; cg; %ca=caxis; caxis(ca/2);
% 	pause(0.7);
% end;
% 
% for idx = 1:nEc
% 	tmp = squeeze(im_SEMC_mSl(:,:,1,idx));
% 	a(idx) = sum(tmp(:));
% end;
% figure;plot(a,'.-');
