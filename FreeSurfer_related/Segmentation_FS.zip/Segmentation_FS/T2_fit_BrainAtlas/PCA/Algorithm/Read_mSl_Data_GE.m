
function [dcm_info,dcm_info_parsed,im_SEMC_mSl,slices_info] = Read_mSl_Data_GE(SEMCDataDir)

% SEMCDataDir = '/Users/noambe/Dropbox/1/Bertrand_GE_PET_MR/2017_08_04_Data/T2mapauto';

fname = dir(SEMCDataDir);

dcm_fnames    = {};
dat_fnames    = {};
for idx = 1:length(fname)
	% skip folders and files starting with '.'
	if (fname(idx).isdir) || (fname(idx).name(1) == '.')
		continue;
	end;
	
	ftype = lower(fname(idx).name(end-2:end));
	fn    = fname(idx).name;
	
	% Collect DICOM files
	if (strcmpi(ftype,'dcm')) || ...
	   (strcmpi(ftype,'ima')) || ...
	   (strcmpi(ftype,'img')) || ...
	   (isdicomfile([SEMCDataDir filesep fn]))
		dcm_fnames{end+1} = fn;
		continue;
	end;

	% Check for raw dat files
	if (strcmpi(ftype,'dat'))
		dat_fnames{end+1} = fn;
		continue;
	end;
end;

reload_dcm_flag = 0;

% Check if we need to reconstruct DICOM images manually from raw data file
if (length(dat_fnames) > 1)
	error('Load Error: too many raw data files (%1.0f)',length(dat_fnames));
end;

% Perform the reconstruction
if (length(dat_fnames) == 1) && (length(dcm_fnames) == 1)
	representative_dcm_fn = dcm_fnames{1};
	emc_reconstruct_dicoms_from_raw_data(SEMCDataDir,dat_fnames{1},representative_dcm_fn);
	reload_dcm_flag = 1;
	
% Reconstruction already performed - just load the DICOMs
elseif (length(dat_fnames) == 1)
	reload_dcm_flag = 1;
end;

if (reload_dcm_flag)
	% Re-collect the list of DICOMs
	fname = dir(SEMCDataDir);

	dcm_fnames = {};
	for idx = 1:length(fname)
		% Load only DICOMs with a prefix of 'Reconstructed_dcm'
		if strfind(fname(idx).name,'Reconstructed_dcm')
			dcm_fnames{end+1} = fname(idx).name;
		end;
	end;
end;
if (isempty(dcm_fnames))
	[dcm_info,dcm_info_parsed,im_SEMC_mSl,slices_info] = deal([]);
	uiwait(msgbox('Error: No files found in DICOM directory'));
	return;
end;

nImages  = length(dcm_fnames);
dcm_info = dicominfo([SEMCDataDir filesep dcm_fnames{1}]);

parfor idx = 1:nImages
	im_SEMC(:,:,idx) = double(dicomread([SEMCDataDir,'/',dcm_fnames{idx}]));
	tmp_info(idx)    = dicominfo([SEMCDataDir,'/',dcm_fnames{idx}]);
	sl_loc_arr(idx)  = tmp_info(idx).SliceLocation;
	ec_num_arr(idx)  = tmp_info(idx).EchoNumber;
end;

nSl = length(unique(sl_loc_arr));
nEc = max(ec_num_arr);

if (mod((nImages),nEc) ~= 0)
    uiwait(msgbox(sprintf('Error: mismatch between number of echoes (%1.0f) and number of files (%1.0f)',dcm_info_parsed.lContrasts, length(dcm_fnames))));
	error('Exiting...');
else
    declare_substage(['Reading ',num2str(nEc),' echoes (# of slices = ' num2str(round((nImages)/nEc)) ')']);
end;

sl_loc = unique(sl_loc_arr);
sl_loc = sort(sl_loc);

im_SEMC_mSl = zeros([size(im_SEMC,1),size(im_SEMC,2),nSl,nEc]);
for sl_idx = 1:length(sl_loc)
	% Extract current slice
	cur_slice_loc             = sl_loc(sl_idx);
	tmp_slc_locs              = find(sl_loc_arr == cur_slice_loc);
	tmp_im_SEMC_per_slc       = im_SEMC(:,:,tmp_slc_locs);

	tmp_ec                    = ec_num_arr(tmp_slc_locs);
	
	% Sort echo times
	[~,tmp_ec_idx]            = sort(tmp_ec);
	tmp_im_SEMC_per_slc       = tmp_im_SEMC_per_slc(:,:,tmp_ec_idx);
	im_SEMC_mSl(:,:,sl_idx,:) = tmp_im_SEMC_per_slc;
end;

slices_info.slices_loc = sl_loc;

dcm_info_parsed.lContrasts = nEc;
TE                         = 6104*1e-6;
dcm_info_parsed.alTE       = 0:TE:TE*nEc;
dcm_info_parsed.sl_thick   = 3;
dcm_info_parsed.ref_ang    = 180;

return;


%%
m=3; n=3; fh=figure;
for si = 15 %1:nSl
	ca=[];
	for ei = 1:nEc
		figure(fh);
		subplot(m,n,ei); imagesc(squeeze(im_SEMC_mSl(:,:,si,ei))); ai; title(sprintf('sl=%1.0f, ec=%1.0f',si,ei));
		if (isempty(ca))
			ca = caxis;
		end;
		caxis(ca/3);
	end;
% 	pause(5);
end;

fp(im_SEMC_mSl(80 ,70 ,15,:));
fp(im_SEMC_mSl(200,100,15,:));

