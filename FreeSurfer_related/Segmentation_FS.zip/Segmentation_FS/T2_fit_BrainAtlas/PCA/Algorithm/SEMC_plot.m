
function [UD, SEMC_stats_cell] = SEMC_plot(UD, RootDir, SEMCDataDir, roiShape, Nroi, roiOnT2orPD, ...
                                           colormap_f, T2ax, PDax, exp_fit,save_flag)

[pathstr, dir_name, ext] = fileparts(SEMCDataDir);
name = [dir_name '_sl' num2str(UD.slices_loc(UD.active_sl))];

T2map_SEMC_emc  = UD.EMC_results(UD.active_sl).T2map_SEMC;
PDmap_SEMC_emc  = UD.EMC_results(UD.active_sl).PDmap_SEMC;
T2map_SEMC_exp  = UD.EMC_results(UD.active_sl).T2map_SEMC_monoexp;  if (isempty(T2map_SEMC_exp)), T2map_SEMC_exp = 0; end;
PDmap_SEMC_exp  = UD.EMC_results(UD.active_sl).PDmap_SEMC_monoexp;  if (isempty(PDmap_SEMC_exp)), PDmap_SEMC_exp = 0; end;
im_SEMC_orig    = UD.EMC_results(UD.active_sl).Original_image;
T2_SEMC_monoexp = UD.EMC_results(UD.active_sl).T2map_SEMC_monoexp;

% Re-create mask according to current mask threshold:
mask_SEMC  = CreateMask(im_SEMC_orig, UD.mask_th);
mask_SEMC  = interp_2D_mat(mask_SEMC, (size(T2map_SEMC_emc,1)/size(mask_SEMC,1)), (size(T2map_SEMC_emc,2)/size(mask_SEMC,2)));
T2map_SEMC_emc = T2map_SEMC_emc .* mask_SEMC;
PDmap_SEMC_emc = PDmap_SEMC_emc .* mask_SEMC;
T2map_SEMC_exp = T2map_SEMC_exp .* mask_SEMC;
PDmap_SEMC_exp = PDmap_SEMC_exp .* mask_SEMC;


% Interpolate images
iT2map_SEMC_emc = interp_2D_mat(T2map_SEMC_emc,UD.interpF,UD.interpF,UD.interp_method);
iPDmap_SEMC_emc = interp_2D_mat(PDmap_SEMC_emc,UD.interpF,UD.interpF,UD.interp_method);
iT2map_SEMC_exp = interp_2D_mat(T2map_SEMC_exp,UD.interpF,UD.interpF,UD.interp_method);
iPDmap_SEMC_exp = interp_2D_mat(PDmap_SEMC_exp,UD.interpF,UD.interpF,UD.interp_method);


% DICOM Masked Maps:
% DICOM write incompatible with this compression.
if strcmp(UD.dcm_info.TransferSyntaxUID, '1.2.840.10008.1.2.4.57'),
    UD.dcm_info.TransferSyntaxUID = '1.2.840.10008.1.2.4.70';
end;

% Re-write DICOMs
if (save_flag)
dicomwrite(iT2map_SEMC_emc, [RootDir,'/EMC_Results/',name,'_T2map_EMC.dcm'], UD.dcm_info);
dicomwrite(iPDmap_SEMC_emc, [RootDir,'/EMC_Results/',name,'_PDmap_EMC.dcm'], UD.dcm_info);
end;
if (exp_fit && (~isempty(T2_SEMC_monoexp)))
    T2_SEMC_monoexp = T2_SEMC_monoexp .* mask_SEMC;
	iT2_SEMC_monoexp = interp_2D_mat(T2_SEMC_monoexp,UD.interpF,UD.interpF,UD.interp_method);
	if (save_flag)
    dicomwrite(iT2_SEMC_monoexp, [RootDir,'/EMC_Results/',name,'_T2map_monoexp.dcm'], UD.dcm_info);
	end;
end;
% linkaxes([A,B],'xy');

% reset(A); reset(B);
% cla(A); cla(B);
% s = size(T2_SEMC_fit2sim);
% set(A,'PlotBoxAspectRatio',[s(:)', 1]);
% set(B,'PlotBoxAspectRatio',[s(:)', 1]);

T2_SEMC_val_emc = zeros(1,Nroi);
T2_SEMC_std_emc = zeros(1,Nroi);
PD_SEMC_val_emc = zeros(1,Nroi);
PD_SEMC_std_emc = zeros(1,Nroi);
T2_SEMC_val_exp = zeros(1,Nroi);
T2_SEMC_std_exp = zeros(1,Nroi);
PD_SEMC_val_exp = zeros(1,Nroi);
PD_SEMC_std_exp = zeros(1,Nroi);
if Nroi || ( ( isfield(UD.EMC_results(UD.active_sl),'Nroi'  ))  && ...
             (~isempty(UD.EMC_results(UD.active_sl).Nroi    ))  && ...
             (         UD.EMC_results(UD.active_sl).Nroi > 0))
	ln_color = [.5 .0 .0];
	ln_wdth  = 2.0;
	
	% -------------------------------------------------------------------------------------------------
	% Check if ROIs are already present. If they are, check if their number has increased. 
	% -------------------------------------------------------------------------------------------------
	if ( isfield(UD.EMC_results(UD.active_sl),'ROIsMSK')  &&  ...
	    ~isempty(UD.EMC_results(UD.active_sl).ROIsMSK  )  &&  ...
	            (UD.EMC_results(UD.active_sl).Nroi ~=0 ) )
		
		% if interpolation factor changed, re-size ROI masks
		tmpF = size(iT2map_SEMC_emc,1) / size((UD.EMC_results(UD.active_sl).ROIsMSK{1}),1);
		if (tmpF ~= 1)
			for idx = 1:(UD.EMC_results(UD.active_sl).Nroi)
				UD.EMC_results(UD.active_sl).ROIsMSK{idx} = interp_2D_mat(double(UD.EMC_results(UD.active_sl).ROIsMSK{idx}),tmpF,tmpF);
				UD.EMC_results(UD.active_sl).ROIsX  {idx} = UD.EMC_results(UD.active_sl).ROIsX  {idx} * tmpF;
				UD.EMC_results(UD.active_sl).ROIsY  {idx} = UD.EMC_results(UD.active_sl).ROIsY  {idx} * tmpF;
				UD.EMC_results(UD.active_sl).ROIsDT {idx} = UD.EMC_results(UD.active_sl).ROIsDT {idx} * tmpF;
				UD.EMC_results(UD.active_sl).ROIsPOS{idx} = UD.EMC_results(UD.active_sl).ROIsPOS{idx} * tmpF;
			end;
		end;
		
		ROIsMSK  = UD.EMC_results(UD.active_sl).ROIsMSK;
		ROIsX    = UD.EMC_results(UD.active_sl).ROIsX;
		ROIsY    = UD.EMC_results(UD.active_sl).ROIsY;
		ROIsDT   = UD.EMC_results(UD.active_sl).ROIsDT;
		ROIsPOS  = UD.EMC_results(UD.active_sl).ROIsPOS;
		
		% Add ROIs
		if (Nroi  > UD.EMC_results(UD.active_sl).Nroi)
			Nroi2 = Nroi - UD.EMC_results(UD.active_sl).Nroi;
			switch roiOnT2orPD
				case 1
					cla(T2ax);
					plot_PD_map(PDax,iPDmap_SEMC_emc,iT2map_SEMC_emc,UD);
					[ROIsMSK2, ROIsX2, ROIsY2, ROIsDT2, ROIsPOS2] = roi_selector(PDax, roiShape,     iPDmap_SEMC_emc, ln_color, Nroi2);
				case 2
					cla(PDax);
					plot_T2_map(T2ax,iT2map_SEMC_emc,UD);
					[ROIsMSK2, ROIsX2, ROIsY2, ROIsDT2, ROIsPOS2] = roi_selector(T2ax, roiShape, 1e3*iT2map_SEMC_emc, ln_color, Nroi2);
				otherwise
					uiwait(msgbox('Internal inconsistency in roiOnT2orPD'));
			end;
			
			ROIsMSK  = [ROIsMSK ROIsMSK2];
			ROIsX    = [ROIsX   ROIsX2  ];
			ROIsY    = [ROIsY   ROIsY2  ];
			ROIsDT   = [ROIsDT  ROIsDT2 ];
			ROIsPOS  = [ROIsPOS ROIsPOS2];
		end;
		
	% Re-create all ROIs from scratch
	else
		switch roiOnT2orPD
			case 1
				cla(T2ax);
				plot_PD_map(PDax,iPDmap_SEMC_emc,iT2map_SEMC_emc,UD);
				[ROIsMSK, ROIsX, ROIsY, ROIsDT, ROIsPOS] = roi_selector(PDax, roiShape,     iPDmap_SEMC_emc, ln_color, Nroi);
			case 2
				cla(PDax);
				plot_T2_map(T2ax,iT2map_SEMC_emc,UD);
				[ROIsMSK, ROIsX, ROIsY, ROIsDT, ROIsPOS] = roi_selector(T2ax, roiShape, 1e3*iT2map_SEMC_emc, ln_color, Nroi);
			otherwise
				uiwait(msgbox('Internal inconsistency in roiOnT2orPD'));
		end;
	end;
	

	% ------------------------------------------
	% Collect statistics and plot ROIs on T2 map
	% ------------------------------------------
	plot_T2_map(T2ax,iT2map_SEMC_emc,UD);   hold on;
	for roi_idx = 1:Nroi
		ROImsk = ROIsMSK{roi_idx};
		ROIx   = ROIsX  {roi_idx};
		ROIy   = ROIsY  {roi_idx};
		ROIDT  = ROIsDT {roi_idx};
		ROIpos = ROIsPOS{roi_idx};

		tmp1 = iT2map_SEMC_emc(:).*ROImsk(:);
		tmp2 = iT2map_SEMC_exp(:).*ROImsk(:);
		tmp1 = tmp1(ROImsk ~= 0);
		tmp2 = tmp2(ROImsk ~= 0);
		T2_SEMC_val_emc(roi_idx) = 1e3*mean(tmp1); % ROI mean
		T2_SEMC_val_exp(roi_idx) = 1e3*mean(tmp2); % ROI mean
		T2_SEMC_std_emc(roi_idx) = 1e3*std(tmp1);
		T2_SEMC_std_exp(roi_idx) = 1e3*std(tmp2);

		if ROIDT
			line(ROIx,ROIy,'LineWidth',2,'Color',ln_color);
			text(ROIx(1),ROIy(1),['\fontsize{16}\color[rgb]{1 1 1}\bf',num2str(roi_idx)]);
		else
			ROIpos(ROIpos==0) = 1;
			rectangle('Position', ROIpos, 'Curvature', [1 1], 'LineWidth', ln_wdth, 'EdgeColor', ln_color);
			text(ROIpos(1,1),ROIpos(1,2),['\fontsize{16}\color[rgb]{1 1 1}\bf',num2str(roi_idx)])
		end;
	end;
	hold off;
	zoom reset;
	cima(colormap_f);
	T2_SEMC_stats_emc = [transpose(1:Nroi),T2_SEMC_val_emc(:),T2_SEMC_std_emc(:)];
	T2_SEMC_stats_exp = [transpose(1:Nroi),T2_SEMC_val_exp(:),T2_SEMC_std_exp(:)];
    
	% ------------------------------------------
	% Collect statistics and plot ROIs on PD map
	% ------------------------------------------
	plot_PD_map(PDax,iPDmap_SEMC_emc,iT2map_SEMC_emc,UD);   hold on;
	for roi_idx = 1:Nroi
		ROImsk = ROIsMSK{roi_idx};
		ROIx   = ROIsX  {roi_idx};
		ROIy   = ROIsY  {roi_idx};
		ROIDT  = ROIsDT {roi_idx};
		ROIpos = ROIsPOS{roi_idx};

		tmp1 = iPDmap_SEMC_emc(:).*ROImsk(:);
		tmp2 = iPDmap_SEMC_exp(:).*ROImsk(:);
		tmp1 = tmp1(ROImsk ~= 0);
		tmp2 = tmp2(ROImsk ~= 0);
		PD_SEMC_val_emc(roi_idx) = mean(tmp1); % ROI mean
		PD_SEMC_val_exp(roi_idx) = mean(tmp2); % ROI mean
		PD_SEMC_std_emc(roi_idx) = std(tmp1);
		PD_SEMC_std_exp(roi_idx) = std(tmp2);

		if ROIDT
			line(ROIx,ROIy,'LineWidth',ln_wdth,'Color',ln_color);
			text(ROIx(1),ROIy(1),['\fontsize{16}\color[rgb]{1 1 1}\bf',num2str(roi_idx)]);
		else
			ROIpos(ROIpos==0) = 1;
			rectangle('Position', ROIpos, 'Curvature', [1 1], 'LineWidth', ln_wdth, 'EdgeColor', ln_color);
			text(ROIpos(1,1),ROIpos(1,2),['\fontsize{16}\color[rgb]{1 1 1}\bf',num2str(roi_idx)])
		end;
	end;
	hold off;
	zoom reset;
	cima(colormap_f);
	PD_SEMC_stats_emc = [PD_SEMC_val_emc(:),PD_SEMC_std_emc(:)];
	PD_SEMC_stats_exp = [PD_SEMC_val_exp(:),PD_SEMC_std_exp(:)];
    
% 	for (idx_=1:length(T2_SEMC_fit2sim_stats)),  tmp = num2str(round(T2_SEMC_fit2sim_stats(idx_)*100)/100,2); T2_SEMC_fit2sim_stats(idx_) = str2num(tmp);  end;
% 	for (idx_=1:length(PD_SEMC_fit2sim_stats)),  tmp = num2str(round(PD_SEMC_fit2sim_stats(idx_)*100)/100,2); PD_SEMC_fit2sim_stats(idx_) = str2num(tmp);  end;
%   SEMC_stats = [T2_SEMC_fit2sim_stats, PD_SEMC_fit2sim_stats];

	% ------------------------------------
	% Round up and consolidate statistics
	% ------------------------------------
	T2_SEMC_stats_emc = round(T2_SEMC_stats_emc*1e1)/1e1;
	T2_SEMC_stats_exp = round(T2_SEMC_stats_exp*1e1)/1e1;
	PD_SEMC_stats_emc = round(PD_SEMC_stats_emc*1e3)/1e3;
	PD_SEMC_stats_exp = round(PD_SEMC_stats_exp*1e3)/1e3;
	
	SEMC_stats         = [T2_SEMC_stats_emc, PD_SEMC_stats_emc];
	SEMC_stats_monoexp = [T2_SEMC_stats_exp, PD_SEMC_stats_exp];
	n = size(SEMC_stats);
	for k1 = 1:n(1)
		for k2 = 1:n(2)
			SEMC_stats_cell{k1,k2} = num2str(SEMC_stats(k1,k2)); %#ok<*AGROW>
		end;
	end;

else
	ROIsMSK            = {};
	ROIsX              = {};
	ROIsY              = {};
	ROIsDT             = {};
	ROIsPOS            = {};
	SEMC_stats         = [];
	SEMC_stats_monoexp = [];
	SEMC_stats_cell    = {};

% 	iT2map_SEMC = interp_2D_mat(T2map_SEMC,UD.interpF,UD.interpF,UD.interp_method);
% 	axes(T2ax);   imagesc(1e3*iT2map_SEMC);  ai; cima(colormap_f);
	plot_T2_map(T2ax,iT2map_SEMC_emc,UD);   hold on;
	
% 	if roi_s == 2,
% 		zoom reset;
% 	end;
% 	iPDmap_SEMC = interp_2D_mat(PDmap_SEMC,UD.interpF,UD.interpF,UD.interp_method);
% 	axes(PDax);   imagesc(iPDmap_SEMC);  ai; cima(colormap_f);
	plot_PD_map(PDax,iPDmap_SEMC_emc,iT2map_SEMC_emc,UD);   hold on;
	
	cima(colormap_f);
% 	if roi_s == 1,
% 		zoom reset;
% 	end;
end;


% -----------
%  Save data
% -----------
% Set data in EMC results structure
UD.EMC_results(UD.active_sl).T2map_SEMC_masked         = iT2map_SEMC_emc;
UD.EMC_results(UD.active_sl).PDmap_SEMC_masked         = iPDmap_SEMC_emc;
if (exp_fit && (~isempty(T2_SEMC_monoexp)))
UD.EMC_results(UD.active_sl).T2map_SEMC_monoexp_masked = iT2_SEMC_monoexp;
else
UD.EMC_results(UD.active_sl).T2map_SEMC_monoexp_masked = [];
end;

UD.EMC_results(UD.active_sl).interpF                   = UD.interpF;
UD.EMC_results(UD.active_sl).Nroi                      = Nroi;
UD.EMC_results(UD.active_sl).ROIsMSK                   = ROIsMSK;
UD.EMC_results(UD.active_sl).ROIsX                     = ROIsX;
UD.EMC_results(UD.active_sl).ROIsY                     = ROIsY;
UD.EMC_results(UD.active_sl).ROIsDT                    = ROIsDT;
UD.EMC_results(UD.active_sl).ROIsPOS                   = ROIsPOS;

UD.EMC_results(UD.active_sl).SEMC_stats                = SEMC_stats;
UD.EMC_results(UD.active_sl).SEMC_stats_monoexp        = SEMC_stats_monoexp;

% Save
% results_fn = get_EMC_fit_results_fn(RootDir,SEMCDataDir);
% if (save_flag)
% save_EMC_results(results_fn,UD);
% end;
clear EMC_results;

set(T2ax,'DataAspectRatioMode','auto');
set(PDax,'DataAspectRatioMode','auto');
% linkaxes([A,B],'xy');

return;


