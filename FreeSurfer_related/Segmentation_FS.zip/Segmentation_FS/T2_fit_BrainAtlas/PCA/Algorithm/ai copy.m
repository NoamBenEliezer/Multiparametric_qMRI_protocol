function ai()

axis image;
axis off;