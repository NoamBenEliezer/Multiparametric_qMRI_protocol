function fout = bd_scan(RootDir, DInfo)

dname = dir([RootDir,'/DB']);
flagship = 0;
fout = [];
for k = length(dname):-1:1
	% remove folders starting with .
	if (dname(k).name(1) == '.')
		dname(k) = [];
		continue;
	end;
	 if dname(k).isdir
		dname(k).name;
		fname = dir([RootDir,'/DB/',dname(k).name]);
		for l = length(fname):-1:1
			% Skip Hidden Files.
			if ((fname(l).name(1) == '.')||(fname(l).isdir))
				fname(l) = [];
				continue;
			end;
			if strcmp(fname(l).name(end-2:end),'mat')
				fname(l).name;
				dbase = [RootDir,'DB/',dname(k).name '/' fname(l).name];
				load(dbase,'software_version','TE_arr','refoc_angle','acq_bw','slice_thickness','RF_mode');
% 				(~isempty(strfind(DInfo{1,2},software_version)))
% 				(((1e+6)*TE_arr(1))==(1e-0)*str2double(DInfo{2,2}))
% 				TE_arr(1)
% 				(1e-6)*str2double(DInfo{2,2})
% 				(str2double(DInfo{6,2}) == refoc_angle)
% 				(str2double(DInfo{3,2}) == acq_bw)
% 				(str2double(DInfo{5,2}) == slice_thickness)

				% Add some leniency on parameter matching - allow 1% mismatch of refocusing angle and 2% in acq BW
				if (~isempty(strfind(DInfo{1,2},software_version)))                                                             && ...
				   (round((1e+6)*TE_arr(1)) == round((1e-0)*str2double(DInfo{2,2})))                                            && ...
				   ((str2double(DInfo{6,2}) == refoc_angle) || (100*(abs(str2double(DInfo{6,2})-refoc_angle)/refoc_angle) < 1)) && ...
				   ((str2double(DInfo{3,2}) == acq_bw     ) || (100*(abs(str2double(DInfo{3,2})-acq_bw     )/acq_bw     ) < 2)) && ...
				   (str2double(DInfo{5,2})  == slice_thickness)
					switch RF_mode
					case 2
						if strcmp(DInfo{7,2},'Norm')
							flagship = flagship + 1;
							fout{flagship} = [RootDir,'/DB/',dname(k).name '/' fname(l).name];
						end;
					case 3
						if strcmp(DInfo{7,2},'Low SAR')
							flagship = flagship + 1;
							fout{flagship} = [RootDir,'/DB/',dname(k).name '/' fname(l).name];
						end;
					otherwise
						continue;
					end;
				end;
			end;
		end;
	end;
end;

