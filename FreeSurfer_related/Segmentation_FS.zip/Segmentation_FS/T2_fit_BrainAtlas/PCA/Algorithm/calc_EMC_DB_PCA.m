
% PCA EMC DB

function [PCA_st] = calc_EMC_DB_PCA(sim_EMC_mat,PCA_flag,nPCs)

if (~exist('nPCs','var')) || (nPCs <= 0) || isempty(nPCs)
	nPCs = 5;
end;

[nB0,nB1,nT1,nT2,ETL] = size(sim_EMC_mat);

% % % % switch PCA_flag
% % % % 	% ==  PCA T2 vals only per each B1 val  ==
% % % % 	case 1
% % % % 		N = nT2;       % size(D,1);       % # of EMCs
% % % % 		
% % % % 		sim_EMC_mat_PC_vecs = zeros(nB0,nB1,nT1,ETL,nPCs);
% % % % 		sim_EMC_mat_PC_mean = zeros(nB0,nB1,nT1,ETL     );
% % % % 		sim_EMC_mat_PC      = zeros(nB0,nB1,nT1,N  ,nPCs);
% % % % 		
% % % % 		for B0_idx = 1:nB0
% % % % 			for B1_idx = 1:nB1
% % % % 				for T1_idx = 1:nT1
% % % % 					
% % % % 					D        = abs(squeeze(sim_EMC_mat(B0_idx,B1_idx,T1_idx,:,:)));
% % % % 					mean_D   = mean(D,1);
% % % % 					mean_sub = repmat(mean_D,N,1);
% % % % 					U        = D - mean_sub;
% % % % 					
% % % % 					% Calculate the covariance matrix
% % % % 					covD = (transpose(U)*U) / (N-1);	  % Identical to MATLAB's  cov(U)
% % % % 					
% % % % 					% Find eigenvalues, and eigenvectors (PCs)
% % % % 					[EMC_PC,covD_eigVals] = eig(covD);
% % % % 					covD_eigVals_arr      = diag(covD_eigVals);
% % % % 					
% % % % 					% Sort PCs according to magnitude
% % % % 					[~,eig_idcs] = sort(abs(covD_eigVals_arr),1,'descend');
% % % % 					EMC_PC = EMC_PC(:,eig_idcs);
% % % % 					EMC_PC_reduced = EMC_PC(:,1:nPCs);
% % % % 					
% % % % 					% Calculate a compressed EMC mat
% % % % 					D_compressed = U * EMC_PC_reduced;
% % % % 					
% % % % 					% Save PCA info for future transformations
% % % % 					sim_EMC_mat_PC_vecs(B0_idx,B1_idx,T1_idx,:,:) = EMC_PC_reduced;   % for transforming experimantal EMC: Trans matrix
% % % % 					sim_EMC_mat_PC_mean(B0_idx,B1_idx,T1_idx,:  ) = mean_D;           % for transforming experimantal EMC: mean of D
% % % % 					sim_EMC_mat_PC     (B0_idx,B1_idx,T1_idx,:,:) = D_compressed;     % the copressed EMC database
% % % % 				end;
% % % % 			end;
% % % % 		end;
% % % % 		
% % % % 		PCA_st.PCA_flag             = PCA_flag;
% % % % 		PCA_st.nPCs                 = nPCs;
% % % % 		PCA_st.sim_EMC_mat_PC       = sim_EMC_mat_PC;
% % % % 		PCA_st.sim_EMC_mat_PC_vecs  = sim_EMC_mat_PC_vecs;
% % % % 		PCA_st.sim_EMC_mat_PC_mean  = sim_EMC_mat_PC_mean;
% % % % 		
% % % % 	case 2
		% ==  PCA T2 & B1 vals jointly  ==
		
		N = nT2*nB1;             % # of EMCs
		
		sim_EMC_mat_PC_vecs = zeros(nB0,nT1,ETL,nPCs);
		sim_EMC_mat_PC_mean = zeros(nB0,nT1,ETL     );
		sim_EMC_mat_PC      = zeros(nB0,nB1,nT1,nT2,nPCs);
		% 		sim_EMC_mat_PC      = zeros(nB0_,nT1_,N   ,nPCs);
		
		% Spread the EMC DB for T2 and B1 along one single dimension
		sim_EMC_mat_spread = zeros(nB0,nT1,nB1*nT2,ETL);
		for B0_idx = 1:nB0
			for B1_idx = 1:nB1
				for T1_idx = 1:nT1
					for T2_idx = 1:nT2
						sim_EMC_mat_spread(B0_idx,T1_idx,(B1_idx-1)*nT2 + T2_idx,:) = squeeze(sim_EMC_mat(B0_idx,B1_idx,T1_idx,T2_idx,:));
					end;
				end;
			end;
		end;
		
		for B0_idx = 1:nB0
			for T1_idx = 1:nT1
				
				D        = abs(squeeze(sim_EMC_mat_spread(B0_idx,T1_idx,:,:)));
				mean_D   = mean(D,1);
				mean_sub = repmat(mean_D,N,1);
				U        = D;% - mean_sub;
				
				% NS !!!!!
% 				mean_D   = mean(D,2);
% 				mean_sub = repmat(mean_D,1,size(D,2));
% 				U        = D - mean_sub;
				
				% Calculate the covariance matrix
				covD = (transpose(U)*U) / (N-1);	  % Identical to MATLAB's  cov(U)
				
				% Find eigenvalues, and eigenvectors (PCs)
				[EMC_PC,covD_eigVals] = eig(covD);
				covD_eigVals_arr = diag(covD_eigVals);
				
				% figure; plot(covD_eigVals_arr,'.-');
				
				% Sort PCs according to magnitude
				[~,eig_idcs] = sort(abs(covD_eigVals_arr),1,'descend');
				EMC_PC = EMC_PC(:,eig_idcs);
				EMC_PC_reduced = EMC_PC(:,1:nPCs);
				
				% Calculate a compressed EMC mat
				D_compressed = U * EMC_PC_reduced;
				
				% reshape the EMC mat to have B1, T2 and PC dimension
				clear tmp;
				tmp = reshape(D_compressed,nT2,nB1,nPCs);
				D_compressed = permute(tmp,[2,1,3]);
				
				% Save PCA info for future transformations
				sim_EMC_mat_PC_vecs(B0_idx,T1_idx,:,:)   = EMC_PC_reduced;   % for transforming experimantal EMC: Trans matrix
				sim_EMC_mat_PC_mean(B0_idx,T1_idx,:  )   = mean_D;           % for transforming experimantal EMC: mean of D
				sim_EMC_mat_PC     (B0_idx,:,T1_idx,:,:) = D_compressed;     % the copressed EMC database
			end;
		end;
		
		PCA_st.PCA_flag             = PCA_flag;
		PCA_st.nPCs                 = nPCs;
		PCA_st.sim_EMC_mat_PC       = sim_EMC_mat_PC;
		PCA_st.sim_EMC_mat_PC_vecs  = sim_EMC_mat_PC_vecs;
		PCA_st.sim_EMC_mat_PC_mean  = sim_EMC_mat_PC_mean;
		
% % % % end; % Switch PCA_flag

return;


