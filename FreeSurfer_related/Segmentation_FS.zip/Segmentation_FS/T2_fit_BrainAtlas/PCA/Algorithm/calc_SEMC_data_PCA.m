
% PCA SEMC experimental data

function [im_SEMC_PCA] = calc_SEMC_data_PCA(PCA_st,im_SEMC)

% if (PCA_st.PCA_flag == 2)
	clear tmp1 tmp2;
	[Nx,Ny,ETL] = size(im_SEMC);
	tmp1 = reshape(im_SEMC,Nx*Ny,ETL);
	
	% NS!!!
% 	mean_tmp1   = mean(tmp1,2);
% 	mean_sub = repmat(mean_tmp1,1,size(tmp1,2));
% 	tmp1        = tmp1 - mean_sub;
	
	PCA_Transform_mat = squeeze(PCA_st.sim_EMC_mat_PC_vecs);
	
	tmp2 = tmp1 * PCA_Transform_mat;
	im_SEMC_PCA = reshape(tmp2,Nx,Ny,size(tmp2,2));
% else
% 	im_SEMC_PCA = im_SEMC;
% end;

return;


