function cima(colormaps_f)

switch colormaps_f,
	case 1
		colormap gray;
	case 2
		colormap jet;
	case 3
		colormap hot;
	case 4
		colormap parula;
	otherwise
		colormap gray;
end;
colorbar;
