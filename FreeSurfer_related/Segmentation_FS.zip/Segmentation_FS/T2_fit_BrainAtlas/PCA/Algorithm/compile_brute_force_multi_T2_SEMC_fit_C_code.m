
function compile_brute_force_multi_T2_SEMC_fit_C_code()

global EMC_RootDir;

fnames    = {'brute_force_multi_T2_comp_SEMC_fit.c',...
             'brute_force_3_T2_comp_SEMC_fit.c'};
CDir = [EMC_RootDir 'Algorithm' filesep 'C_code' filesep];

for idx = 1:length(fnames)
	fname     = fnames{idx};
	libname   = [fname(1:end-1) mexext];

	full_file_nm = [CDir fname  ];
	full_dll_nm  = [CDir libname];

	if (exist(full_dll_nm,'file'))
		file_prop = dir(full_file_nm  );   file_date = datenum(file_prop.date);
		dll_prop  = dir(full_dll_nm );   dll_date  = datenum(dll_prop.date);
		if (file_date < dll_date)
			continue;
		end;
	end;

	fprintf('Compiling %s\n',full_file_nm);
	mex(full_file_nm);
	fprintf('Done.\n');

	movefile(libname,CDir,'f');
end;

return;

