
function compile_emc_fit_C_code(EMCpkgRootDir)

fname     = 'emc_fit_kernel_C.c';
libname   = [fname(1:end-1) mexext];

full_file_nm = [EMCpkgRootDir, 'Algorithm' filesep 'C_code' filesep fname  ];
full_dll_nm  = [EMCpkgRootDir, 'Algorithm' filesep 'C_code' filesep libname];

if (exist(full_dll_nm,'file'))
	file_prop = dir(full_file_nm);   file_date = datenum(file_prop.date);
	dll_prop  = dir(full_dll_nm );   dll_date  = datenum(dll_prop.date);
	if (file_date < dll_date)
		return;
	end;
end;

fprintf('Compiling %s\n',full_file_nm);
mex(full_file_nm,'COMPFLAGS="/openmp"');
fprintf('Done.\n');

movefile(libname,[EMCpkgRootDir, 'Algorithm' filesep 'C_code' filesep],'f');

return;

