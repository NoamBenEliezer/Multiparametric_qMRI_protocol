function declare_stage(str)
disp(sprintf('\n------------------------------------------------------'));
disp(sprintf(  '%s',str                                                ));
disp(sprintf(  '------------------------------------------------------'));

