function declare_substage(str)

disp(sprintf('== %s ==',str));

return;

