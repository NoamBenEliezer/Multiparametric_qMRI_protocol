function fig1 = fit_msg(my_msg)

set(0,'Units','pixels');
scnsize = get(0,'ScreenSize');
fig1 = figure;
set(fig1, 'MenuBar', 'none', 'ToolBar', 'none');
pos1 = [scnsize(3)/2,...
        scnsize(4) * (1/2),...
        400,...
        100];
set(fig1,'Position',pos1);
mTextBox = uicontrol('style','text','Position', [2 2 399 99],'FontSize',14);
set(mTextBox,'String',sprintf(['\n' my_msg]));


