%#ok<*NASGU,*ASGLU>

function [EMC_results,slices_info,im_SEMC_mSl_orig,dcm_info_for_GUI,EMC_db_fn,dcm_info,dcm_info_parsed] = ...
			fit_semc(handles,RootDir,SEMCDataDir,mask_th,fit_B1_flag,exp_fit_SEMC, opts)

%         RootDir=[];
declare_stage('Starting EMC fit');
fprintf('  RootDir=%s\n  SEMCDataDir=%s\n\n',RootDir,SEMCDataDir);
clear sim_EMC_mat sim_data;

fit_B0_flag       = 0;
B1constraint_mrgn = 3;         % [%] When provided with an input B1 map, what would be the margin around the input
                               %     B1 value to which the fitting shoud be limited. Default value = 3 %
normalize_F       = 1;         % [1]   Yes - always
PDi               = 1;         %       TE time point used to generate the PD map
EMC_fit_w_phase   = 0;         % [0]   [0: EMC fit using absolute values    |    1: using complex values]
fit_sig_th        = 0.1;       % [0.1] Use echoes up to a certain degree of signal level. Default = 0.1
min_N_echoes      = 3;         % [3]   Anything below 10% of the 1st echo is disregarded unless less than 4 echoes meet the criteria
opt_flag          = 0;         %       EMC matching criterion [0: L2 norm   |  1: corr |   2: L1 norm  ]
C_code_fit        = 1;
multi_T2_fit_flag = 0;
PCA_flag          = 1;         % [0: no PCA  |  1: PCA T2 vals per B1  |  2: PCA T2 & B1 vals jointly]
                               % Option =1 works only if B1_fit=0 (o/w it's impossible to know according to which B1
							   % PCA matrix should the experimental data be transformed.
vendor            = 'Siemens';      % [Bruker | GE | Siemens]
RootDir=[RootDir filesep];
compile_emc_fit_C_code(RootDir);

if (~exist('opts','var'))
	opts.PD          = 1;
	opts.T2          = 1;
	opts.dcm         = 1;
	opts.nii         = 1;
	opts.Siemens_dir = [];
end;

% Reset output parameters
EMC_results     = [];

% -------------------------------------------------------------
%  Read DICOMs data ... smooth ... crop ... resize ... etc
% -------------------------------------------------------------
declare_substage('Reading Data');
% Note: im_SEMC_mSl contains the slices data, SORTED ACCORDING TO INCREASING SLICE ORDER / LOCATION.
%       This is important in order to keep the slice order correct in the saved DICOM images
switch vendor
case 'Siemens'
	[dcm_info,dcm_info_parsed,im_SEMC_mSl,slices_info] = Read_mSl_Data(SEMCDataDir);
	if (~isempty(opts.Siemens_dir))
	[zLocT2Siemens,T2dcm_infoSiemens] = read_siemens_T2maps_dicoms(opts.Siemens_dir);
	if (length(zLocT2Siemens) ~= length(slices_info.slices_loc))
		error('Siemens (%3.0f) and EMC (%3.0f) nunber of slices do not match. Exiting.',length(zLocT2Siemens), length(slices_info.slices_loc));
	end;
	end;
case 'GE'
	[dcm_info,dcm_info_parsed,im_SEMC_mSl,slices_info] = Read_mSl_Data_GE(SEMCDataDir);
end;

im_SEMC_mSl_orig = im_SEMC_mSl;
nSl = size(im_SEMC_mSl,3);

% figure; m=4; n=4;
% for i=1:15
% 	subplot(m,n,i); imagesc(squeeze(im_SEMC_mSl(:,:,4,i))); %caxis([0 0.5]);
% end;


% -------------------------------------------------------------
% Search for database:
% -------------------------------------------------------------
switch vendor
case 'Siemens'
	switch dcm_info_parsed.sTXSPEC.ucRFPulseType
		case 2
			RFPulseType = 'Norm';
		case 4
			RFPulseType = 'Low SAR';
		otherwise
			RFPulseType = 'other';
	end;

	switch dcm_info_parsed.sGRADSPEC.ucMode
		case 1
			GRADSPEC = 'Fast';
		case 2
			GRADSPEC = 'Norm';
		case 4
			GRADSPEC = 'Whisper';
		otherwise
			GRADSPEC = 'other';
	end;
	dcm_info_for_GUI = {'Software version', dcm_info_parsed.sProtConsistencyInfo.tBaselineString;
						'TE'              , num2str(dcm_info_parsed.alTE(2));
						'Pixel Bandwidth' , num2str(dcm_info.PixelBandwidth);
						'Number of Echoes', num2str(dcm_info_parsed.lContrasts);
						'Slice thickness' , num2str(dcm_info_parsed.sSliceArray.asSlice(2).dThickness);
						'Flip Angle'      , num2str(dcm_info_parsed.adFlipAngleDegree(2));
						'RF Mode'         , RFPulseType;
						'GRAD Mode'       , GRADSPEC};

	declare_substage('Searching DataBase:');
	EMC_db_fn = bd_scan(RootDir, dcm_info_for_GUI);
	if ~isempty(EMC_db_fn)
		declare_stage('Possible DB:');
		for x = 1:length(EMC_db_fn)
			declare_substage(EMC_db_fn{x});
		end;
		if length(EMC_db_fn) > 1
			uiwait(msgbox('Error: Multiple DataBases ... Fitting aborted'));
			return;
		end;
		declare_stage(' ');
		if (exist('handles','var') && ~isempty(handles)), set(handles.EMC_DB_fn,'String',EMC_db_fn{1}); end;
	else
		declare_stage('Error: No databse found... Fitting aborted');
		EMC_db_fn{1} = 'Error: No Database found.';
		dcm_info_for_GUI
		h_waitbar = fit_msg('Error: No databse found... Fitting aborted');
		if (exist('handles','var') && ~isempty(handles)), set(handles.EMC_DB_fn,'String','No Database Found.');  end;
		if (exist('handles','var') && ~isempty(handles)), set(handles.DICOM_Table, 'Data', dcm_info_for_GUI);  end;
		return;
	end;

case 'GE'
	dcm_info_for_GUI = {'TE'              , num2str(dcm_info_parsed.alTE(2));
						'Pixel Bandwidth' , num2str(dcm_info.PixelBandwidth);
						'Number of Echoes', num2str(dcm_info_parsed.lContrasts);
						'Slice thickness' , num2str(dcm_info_parsed.sl_thick);
						'Flip Angle'      , num2str(dcm_info_parsed.ref_ang);};
	
	EMC_db_fn = bd_scan_GE(RootDir, dcm_info_for_GUI);
end;

EMC_DB = EMC_db_fn{1};
dcm_info_for_GUI = [{'Data Base',EMC_db_fn{:}}; dcm_info_for_GUI];

% Show and store header info:
[pathstr, dir_name, ext] = fileparts(SEMCDataDir);
if (exist('handles','var') && ~isempty(handles)), set(handles.DICOM_Table, 'Data', dcm_info_for_GUI);  end;

% Load EMC Database
declare_substage('Reading Simulated Data');
sim_data = load(EMC_DB);

% -------------------------------------------------------------
% Global preparations
% -------------------------------------------------------------
if ~isequal(exist('EMC_Results'  , 'dir'),7),   mkdir(RootDir,'EMC_Results'  );   end;

% % Patch for lContrasts=32
% if (dcm_info_parsed.lContrasts == 32)
% 	dcm_info_parsed.lContrasts = 31;
% end;

TEs_SEMC = dcm_info_parsed.alTE(2:dcm_info_parsed.lContrasts+1)*1e-6;
firstTE  = dcm_info_parsed.alTE(2)*1e-6;

% Check consistency
tmp = diff(TEs_SEMC);     % calculate echo spacings
tmp = round(1e3*tmp);     % compare up to 1 us becasue of MATLAB numeric errors
tmp = find(tmp~=tmp(1));  % are all echo spacings identical?
if (~isempty(tmp))
	error('Echo times are not linearly increasing. Aborting');
end;

% -------------------------------------------------------------
%  Reorganize EMC DB
% -------------------------------------------------------------
declare_substage('Read EMC database:');
if (isfield(sim_data,'echo_train_modulation_img'))
sim_EMC_mat = sim_data.echo_train_modulation_img;
else
sim_EMC_mat = sim_data.echo_train_modulation;
end;

% Prepare T2 - Truncate simulation database T2 dimension below the first TE / 2
sim_T2_arr = sim_data.T2_tse_arr;
if (firstTE/2 > sim_T2_arr(1))
	[dummy, loc] = min(abs(sim_T2_arr - firstTE/2));
	
	clear tmp;
	tmp = sim_EMC_mat(:,:,:,(loc+1):end,:);
	sim_EMC_mat = tmp;
	sim_data.T2_tse_arr = sim_data.T2_tse_arr((loc+1):end);
	sim_T2_arr          = sim_T2_arr((loc+1):end);
end;

% Prepare B0
if (~isfield(sim_data,'B0_scaling_arr')) && (ndims(sim_EMC_mat) < 5)
    sim_data.B0_scaling_arr = 0;
    clear tmp;
    tmp(1,:,:,:,:) = sim_EMC_mat;
    sim_EMC_mat = tmp;
end;
if (~fit_B0_flag)
    [dummy, loc] = min(abs(sim_data.B0_scaling_arr - 0));  % neutral value is 0 [Hz]
    clear tmp;
    tmp = zeros(1,size(sim_EMC_mat,2),size(sim_EMC_mat,3),size(sim_EMC_mat,4),size(sim_EMC_mat,5)); % o/w tmp will have only 4 dims
    tmp(1,:,:,:,:) = sim_EMC_mat(loc,:,:,:,:);
    sim_EMC_mat = tmp;
    sim_data.B0_scaling_arr = 0;
end;
sim_B0_arr = sim_data.B0_scaling_arr;

% Prepare T1
if (~isfield(sim_data,'T1_tse_arr')) % || (length(sim_data.T1_tse_arr) == 1)
    if (~isfield(sim_data,'T1_tse_arr'))
        sim_data.T1_tse_arr = sim_data.T1;
    else
        sim_data.T1_tse_arr = sim_data.T1_tse_arr;
    end;
    clear tmp;
    tmp(:,:,1,:,:) = sim_EMC_mat;
    sim_EMC_mat = tmp;
end;
sim_T1_arr = sim_data.T1_tse_arr;

% Prepare B1
if (~isfield(sim_data,'B1_scaling_arr'))
    sim_data.B1_scaling_arr = 1;
    clear tmp;
    tmp(:,1,:,:,:) = sim_EMC_mat;
    sim_EMC_mat = tmp;
end;

if (~fit_B1_flag)
    [dummy, loc] = min(abs(sim_data.B1_scaling_arr - 1));  % neutral value is 100 [%] = 1 in normalized scale
    clear tmp;
    tmp = zeros(size(sim_EMC_mat,1),1,size(sim_EMC_mat,3),size(sim_EMC_mat,4),size(sim_EMC_mat,5)); %#ok
    tmp = sim_EMC_mat(:,loc,:,:,1:size(sim_EMC_mat,5));
    sim_EMC_mat = tmp;
    sim_data.B1_scaling_arr = 1;
end;
sim_B1_arr = sim_data.B1_scaling_arr;

% It's important at this point, to match the EMC DB ETL and the experimental ETL
% Otherwise, the calculation of how many PCs to use in the PCA analysis will be biased.
EMC_DB_ETL = size(sim_EMC_mat,ndims(sim_EMC_mat));
EXPRMN_ETL = dcm_info_parsed.lContrasts;
if (EMC_DB_ETL ~= EXPRMN_ETL)
    fprintf('Simulated n-Echoes (%1.0f) does not match MSE n-Echoes (%1.0f)\n',EMC_DB_ETL,EXPRMN_ETL);
	if (EMC_DB_ETL>EXPRMN_ETL)
	fprintf('Adjusting EMC DB ETL to match acquired data ETL\n');
	sim_EMC_mat = sim_EMC_mat(:,:,:,:,1:EXPRMN_ETL);
	EMC_DB_ETL = EXPRMN_ETL;
	end;
end;


% -------------------------------------------------------------
% set upper and lower bound for fitted T2
% -------------------------------------------------------------
T2minHardLimit  = 0.5*firstTE;      % [sec]
T2maxHardLimit  = sim_T2_arr(end);  % [sec]


% -------------------------------------------------------------
% Normalize the EMC DB
% -------------------------------------------------------------
if (normalize_F)
    sim_EMC_mat = normalize_5D_EMC(sim_EMC_mat);
end;

% -------------------------------------------------------------
% PCA the EMC DB
% -------------------------------------------------------------
if (PCA_flag)
	nPCs         = round(EMC_DB_ETL / 3);
	fprintf('Calculating PCA of the EMC DB (nPCs = %1.0f)\n',nPCs);
	PCA_st       = calc_EMC_DB_PCA(sim_EMC_mat,PCA_flag,nPCs);

% 	db   = transpose(squeeze(sim_EMC_mat));  % [nbe_multi_T2]
	sim_EMC_mat  = PCA_st.sim_EMC_mat_PC;
% 	db_pca = transpose(squeeze(sim_EMC_mat)); % [nbe_multi_T2]

	if (min_N_echoes > nPCs)
		fprintf('Adjusting minimal number of echoed from %1.0f to %1.0f\n',min_N_echoes,nPCs);
		min_N_echoes = nPCs;
	end;
end;

% >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
% ================================================================================================
% ================================================================================================
% Slices loop
h_waitbar = waitbar(0,'Processing T2 maps... please wait.');

for sl_idx = 1:nSl
	declare_stage(sprintf('Processing slice %1.0f (%1.0f)',sl_idx,nSl));
	waitbar(sl_idx/nSl,h_waitbar);
	im_SEMC      = squeeze(im_SEMC_mSl(:,:,sl_idx,:));
	im_SEMC_orig = im_SEMC;
	name         = [dir_name '_sl' num2str(slices_info.slices_loc(sl_idx))];
% 	dcm_info_parsed.ImageOrientationPatient       = slices_info.ImageOrient;
% 	dcm_info_parsed.ImagePositionPatient          = slices_info.ImagePosition;
% 	dcm_info_parsed.InPlanePhaseEncodingDirection = slices_info.PEdir;
% 	dcm_info_parsed.SeriesNumber                  = slices_info.SeriesNumber  (sl_idx);
% 	dcm_info_parsed.InstanceNumber                = slices_info.InstanceNumber(sl_idx);
% 	dcm_info_parsed.SliceLocation                 = slices_info.slices_loc    (sl_idx);
	dcm_info.SliceLocation                        = slices_info.slices_loc    (sl_idx);
	if (~isempty(opts.Siemens_dir))
		smns_idx  = find((zLocT2Siemens - slices_info.slices_loc(sl_idx))==0);
		local_dcm_info = T2dcm_infoSiemens(smns_idx);
	else
		local_dcm_info = dcm_info; % dcm_info_parsed;
	end;
	local_dcm_info.SeriesDescription = SEMCDataDir;
% 	dcm_info_parsed.Private_0029_1020 = smns_info.Private_0029_1020;

% ================================================================================================
% ================================================================================================
% >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

% -------------------------------------------------------------
%  Create masks according to image threshold
% -------------------------------------------------------------
mask_SEMC = CreateMask(im_SEMC, mask_th);


% -------------------------------------------------------------
% Normalize SEMC data
% -------------------------------------------------------------
if (normalize_F)
    im_SEMC_norm = normalize_SEMC(im_SEMC);
else
	im_SEMC_norm = im_SEMC;
end;

%% -------------------------------------------------------------
% nbe_multi_T2
% -------------------------------------------------------------
if (0)
	nTEs_tmp = 15;
	nT2_comp = 10;
	ts   = squeeze(im_SEMC_norm(65,57,1:nTEs_tmp));

	db     = db    (:,(sim_T2_arr < 1));
	db_pca = db_pca(:,(sim_T2_arr < 1));

	db     = db    (1:nTEs_tmp,:);

	if (0)
		tmp_ts = ts;
		for iter = 1:10
			min_norm(iter) = 1e10;
			min_loc(iter) = 0;
			for idx = 1:size(db,2)
				emc_v = squeeze(db(:,idx));
				tmp_norm = norm(tmp_ts-emc_v,2);
				if (tmp_norm < min_norm(iter))
					min_norm(iter) = tmp_norm;
					min_loc(iter) = idx;
				end;
			end;
			tmp_ts = tmp_ts - squeeze(db(:,min_loc));
		end;
	end;

	tmp_T2_arr = sim_T2_arr(sim_T2_arr < 1);
	sparse_T2_arr = calc_equispaced_T2(tmp_T2_arr(1),tmp_T2_arr(end),nT2_comp,0);

	loc = [];
	for idx = 1:length(sparse_T2_arr)
		[~,tmp_idx] = min(abs(sim_T2_arr - sparse_T2_arr(idx)));
		if tmp_idx
			loc = [loc tmp_idx];
		end;
	end;

	db       = db(:,loc);
	db_pca   = db_pca(:,loc);

	% for idx = 1:10
	% db_inv     = pinv(db);
	% fi(db_inv*db - eye(size(db_inv*db))); ai; colorbar;
	% db_inv(db_inv < 0) = 0;
	% fi(db_inv*db - eye(size(db_inv*db))); ai; colorbar;
	% end;

	db_inv     = pinv(db);
	db_pca_inv = pinv(db_pca);

	resd = ts;
	w    = 0;
	for idx = 1:10
	w_tmp  = db_inv*resd;
	w_tmp = w_tmp / sum(abs(w_tmp));
	w = w + w_tmp;
	w = w / sum(abs(w));
	w(w<0)   = 0;
	ts_tmp   = db*w;
	ts_tmp   = ts_tmp / ts_tmp(1);
	resd     = ts - ts_tmp;
	abs_resd = sum(abs(resd));
	fprintf('abs_resd = %3.1f\n',abs_resd);
	end;

	% fi(im_SEMC_norm(:,:,2)); axis image; caxis([0.6 1.4]);

	figure;
	subplot(221); plot(sparse_T2_arr*1000, w,'.-');    title('w');
	subplot(222); plot(   w,'.-'); title('w  =  db inv * ts');
	subplot(223); plot(db*w,'r--'); title('residual  =  db*w - ts'); hold on
				  plot(ts  ,'b.-'); title('ts');
end;
% -------------------------------------------------------------
% -------------------------------------------------------------
%%

% -------------------------------------------------------------
% PCA the image data
% -------------------------------------------------------------
if (PCA_flag)
	im_SEMC_norm = calc_SEMC_data_PCA(PCA_st,im_SEMC_norm);
end;

% ==========================================================
%   EMC fit
% ==========================================================
% declare_substage('EMC fit');
% [nB0, nB1, nT1, nT2, ETL] = size(sim_EMC_mat);

fatwtr_st         = [];

if (C_code_fit && (~multi_T2_fit_flag))
	declare_substage('C-code emc fit kernel');
	
	if (fit_B1_flag) && (B1constraint_mrgn > 0)
		fit_B1_nIter = 2;
		fprintf('Using 2-stage B1 fit\n');
	else
		fit_B1_nIter = 1;
	end;
	inB1map     = 0;
	inB1idx_map = 0;
	
	for idx = 1:fit_B1_nIter
		[B0_SEMC_EMC         , ...
		 B0_SEMC_idx_map     , ...
		 B1_SEMC_EMC         , ...
		 B1_SEMC_idx_map     , ...
		 T1_SEMC_EMC         , ...
		 T1_SEMC_idx_map     , ...
		 T2_SEMC_EMC         , ...
		 T2_SEMC_idx_map     , ...  
		 nEchoes_map_SEMC_EMC, ...
		 T2_spect_SEMC_EMC   ] = emc_fit_kernel_C_wrapper(im_SEMC_norm, size(im_SEMC_norm,ndims(im_SEMC_norm)), EMC_fit_w_phase, ...
											              sim_EMC_mat, fit_sig_th, min_N_echoes,opt_flag, sim_B0_arr, ...
											              sim_B1_arr, sim_T1_arr, sim_T2_arr, inB1idx_map, B1constraint_mrgn);
		
		if (fit_B1_nIter > 1)
		[inB1map,inB1idx_map] = emc_smooth_B1(mask_SEMC,T2_SEMC_EMC*1e3,B1_SEMC_EMC,sim_B1_arr,firstTE*1e3,EXPRMN_ETL);

% 		fi(T2_SEMC_EMC*1e3); title('T2'); caxis([0 200]);
% 		fi(inB1idx_map);     title('inB1idx map');     colorbar; ca=caxis;
% 		fi(B1_SEMC_idx_map); title('B1 SEMC idx map'); colorbar; caxis(ca);

		% Update the output B1 map
		B1_SEMC_EMC     = inB1map;
		B1_SEMC_idx_map = inB1idx_map;
		end;
	end;
elseif (~multi_T2_fit_flag)
	[nEchoes_map_SEMC_EMC, ...
	 T2_SEMC_EMC         , ...
	 T1_SEMC_EMC         , ...
	 B1_SEMC_EMC         , ...
	 T2_SEMC_idx_map     , ...
	 T1_SEMC_idx_map     , ...
	 B1_SEMC_idx_map     ] = emc_fit_kernel_MATLAB_wrapper(im_SEMC_norm, fit_sig_th,min_N_echoes, ...
	                                                       sim_EMC_mat,opt_flag,sim_T2_arr,sim_T1_arr,sim_B1_arr);
else
	[fatwtr_st] = ...
         multi_comp_sparse_SEMC_fit(im_SEMC_norm,mask_SEMC,fit_sig_th,min_N_echoes,opt_flag,sim_EMC_mat,...
	     sim_B0_arr,sim_B1_arr,sim_T1_arr,sim_T2_arr,fit_B1_flag,firstTE);
	B1_SEMC_EMC = fatwtr_st.B1_SEMC_EMC;
	T2_SEMC_EMC = fatwtr_st.wtr_msk*100e-3;
end;

% -------------------------------------------------------------
%  Exponential fit of SEMC data
% -------------------------------------------------------------
if (exp_fit_SEMC)
	% Create representative images and mask maps ... use 1st image or all of them?
	rep_im_SEMC = sum(im_SEMC_norm(:,:,2:end),3);
	rep_im_SEMC = rep_im_SEMC / max(rep_im_SEMC(:));
	
	declare_substage('Exponential fit SEMC data');
	[T2_SEMC_EXP, T2_SEMC_err, nEchoesMat_SEMC_EXP] = Expo_fit_SEMC(rep_im_SEMC, im_SEMC_norm, TEs_SEMC, fit_sig_th, ...
	                                                                min_N_echoes, T2minHardLimit, T2maxHardLimit);
end;


% -------------------------------------------------------------
%  Calculate PD maps
% -------------------------------------------------------------
PD_SEMC_EMC = squeeze(im_SEMC_orig(:,:,PDi))  ./ exp(-TEs_SEMC(PDi)./T2_SEMC_EMC);
PD_SEMC_EMC(T2_SEMC_EMC==0) = 0;
% Normalize PD map:
PD_SEMC_EMC = PD_SEMC_EMC / max(PD_SEMC_EMC(:));

if exp_fit_SEMC
PD_SEMC_EXP = squeeze(im_SEMC_orig(:,:,PDi))  ./ exp(-TEs_SEMC(PDi)./T2_SEMC_EXP);
PD_SEMC_EXP(T2_SEMC_EMC==0) = 0;
% Normalize PD map:
PD_SEMC_EXP = PD_SEMC_EXP / max(PD_SEMC_EXP(:));
end;


% -------------------------------------------------------------
%  Save fitting results
%
%  Save the DICOMs as unsigned int so as to retain the T2 scale.
%  Multiplication by 1000 would retain 1ms T2 resolution. We multiply by 10000 in order to retain one more decimal point
%  yet, at a cost of requirement to divide the maps by 10 in order to go back to [ms] scale
% -------------------------------------------------------------

% Masked Images:
EMC_results(sl_idx).Original_image    = im_SEMC_orig;

EMC_results(sl_idx).B1map_SEMC        = B1_SEMC_EMC;
EMC_results(sl_idx).B1map_SEMC_masked = B1_SEMC_EMC.*mask_SEMC;  %#ok<*AGROW>
EMC_results(sl_idx).T2map_SEMC        = T2_SEMC_EMC;
EMC_results(sl_idx).T2map_SEMC_masked = T2_SEMC_EMC.*mask_SEMC;
EMC_results(sl_idx).T1map_SEMC        = T1_SEMC_EMC;
EMC_results(sl_idx).T1map_SEMC_masked = T1_SEMC_EMC.*mask_SEMC;
EMC_results(sl_idx).PDmap_SEMC        = PD_SEMC_EMC;
EMC_results(sl_idx).PDmap_SEMC_masked = PD_SEMC_EMC.*mask_SEMC;
EMC_results(sl_idx).mask_SEMC         = mask_SEMC;
EMC_results(sl_idx).fatwtr_st         = fatwtr_st;

fn_prf = [RootDir filesep 'EMC_Results' filesep name];

T2dcmF = 1000; % Convert from [sec] to [ms] when saving to DICOM. x1000 will round T2 values to closes whole [ms]

% Save slice information (just because I don't know how to plug all these values in the dicomwrite operation)
% save([fn_prf '_SliceInfo.mat'],'dcm_info_parsed');

% Save DICOMs
if (opts.T2 && opts.dcm)
	local_dcm_info.SeriesDescription = [SEMCDataDir '_EMC_T2map'];
	dicomwrite(uint16(round((EMC_results(sl_idx).T2map_SEMC_masked)*T2dcmF)),...
	           [fn_prf '_T2map_EMC.dcm'], 'ObjectType','MR Image Storage', local_dcm_info);
end;
if (opts.PD && opts.dcm)
	local_dcm_info.SeriesDescription = [SEMCDataDir '_EMC_PDmap'];
	dicomwrite(              EMC_results(sl_idx).PDmap_SEMC_masked          ,...
	           [fn_prf '_PDmap_EMC.dcm'], 'ObjectType','MR Image Storage', local_dcm_info);
end;
if (opts.T2 && opts.nii)
	save_nii(make_nii(       EMC_results(sl_idx).T2map_SEMC_masked)         ,...
	         [fn_prf '_T2map_EMC.nii']);
end;
if (opts.PD && opts.nii)
	save_nii(make_nii (      EMC_results(sl_idx).PDmap_SEMC_masked)         ,...
	         [fn_prf '_PDmap_EMC.nii']);
end;

if exp_fit_SEMC
	EMC_results(sl_idx).T2map_SEMC_monoexp        = T2_SEMC_EXP;
	EMC_results(sl_idx).T2map_SEMC_monoexp_masked = T2_SEMC_EXP.*mask_SEMC;
	EMC_results(sl_idx).PDmap_SEMC_monoexp        = PD_SEMC_EXP;
	EMC_results(sl_idx).PDmap_SEMC_monoexp_masked = PD_SEMC_EXP.*mask_SEMC;
	if (opts.T2 && opts.dcm)
		local_dcm_info.SeriesDescription = [SEMCDataDir '_EXP_T2map'];
		dicomwrite(uint16(round((EMC_results(sl_idx).T2map_SEMC_monoexp_masked)*T2dcmF)),...
		           [fn_prf '_T2map_EXP.dcm'], 'ObjectType','MR Image Storage', local_dcm_info);
	end;
	if (opts.T2 && opts.nii)
		save_nii(make_nii (EMC_results(sl_idx).T2map_SEMC_monoexp_masked)               ,...
		         [fn_prf '_T2map_EXP.nii']);
	end;
else
	EMC_results(sl_idx).T2map_SEMC_monoexp        = [];
	EMC_results(sl_idx).T2map_SEMC_monoexp_masked = [];
	EMC_results(sl_idx).PDmap_SEMC_monoexp        = [];
	EMC_results(sl_idx).PDmap_SEMC_monoexp_masked = [];
end;


% >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
% ================================================================================================
% Slices loop end
end;
close(h_waitbar);
% ================================================================================================
% >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

return;


