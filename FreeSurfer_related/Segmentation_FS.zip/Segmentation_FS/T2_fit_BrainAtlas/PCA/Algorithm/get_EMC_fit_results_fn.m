
function fn = get_EMC_fit_results_fn(RootDir,SEMCDataDir)

[~, dir_name, ~] = fileparts(SEMCDataDir);
fn = [RootDir,'/EMC_Results/',dir_name,'_EMC_fit_Result'];

return;

