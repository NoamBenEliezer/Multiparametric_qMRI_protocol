function [res, dcminfo] = isdicomfile(fname)
dcminfo = dicominfo(fname);
if (isempty(dcminfo))
	res = 0;
else
	res=1;
end;

return;

