function im_SEMC = normalize_SEMC(im_SEMC,L)
if nargin < 2,
    L = size(im_SEMC,3);
    L = 1:L;
end;
for dx = 1:size(im_SEMC,1)
    for dy = 1:size(im_SEMC,2)
        v = transpose(double(squeeze(im_SEMC(dx,dy,L))));
        if (v(1) ~= 0) && (~isnan(v(1)))
            v = v / v(1);
        else
            v = zeros(size(v));
        end;
        im_SEMC(dx,dy,L) = v;
    end;
end;