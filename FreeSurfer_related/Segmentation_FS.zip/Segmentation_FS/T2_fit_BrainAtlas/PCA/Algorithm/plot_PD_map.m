
function plot_PD_map(axH,PDmap,T2map,UD)
cla(axH);
axes(axH);

if (UD.T2weightPD_TEms ~=0)
	T2_SEMC_tmp = T2map;
	T2_SEMC_tmp(T2_SEMC_tmp == 0  ) = 1e-3;
	T2_SEMC_tmp(isnan(T2_SEMC_tmp)) = 1e-3;
	PDmapw = PDmap.*exp(-1e-3*(UD.T2weightPD_TEms)./T2_SEMC_tmp);
else
	PDmapw = PDmap;
end;
PDmapw = PDmapw ./ max(PDmapw(:));

imagesc(PDmapw);
ai; colorbar;
if (~isempty(UD.caPD)),   caxis(UD.caPD);   end;
if (~isempty(UD.axis)),    axis(UD.axis);   end;

return;

