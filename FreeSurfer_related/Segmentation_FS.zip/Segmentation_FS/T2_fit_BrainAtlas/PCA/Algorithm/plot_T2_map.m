
function plot_T2_map(axH,T2map,UD)
cla(axH);
axes(axH);
imagesc(1e3*T2map);
ai; colorbar;
if (~isempty(UD.caT2)),   caxis(UD.caT2);   end;
if (~isempty(UD.axis)),    axis(UD.axis);   end;
% caxis([-0.02 0.25]);

return;

