
function [ROIsMSK, ROIsX, ROIsY, ROIsDTN, ROIsPOS] = roi_selector(mapH, roiShape, img, ln_color, Nroi)
% imagesc(img);   ai;   %caxis(ca);
% zoom reset;
for roi_idx = 1:Nroi,
%     q = fit_msg(['Select ' num2str(nroi-n+1) ' ROI.']);
    switch roiShape
        case 'Point'
            h = impoint(gca,[]);
            setColor(h,ln_color);
            ROImsk = createMask(h);
            ROIpos = round(getPosition(h));
            ROIx   = ROIpos(:,1);
            ROIy   = ROIpos(:,2);
            ROIDT  = 1;
        case 'Line'
            h = imline(gca,[]);
            setColor(h,ln_color);
            ROImsk = createMask(h);
            ROIpos = round(getPosition(h));
            ROIx   = ROIpos(:,1);
            ROIy   = ROIpos(:,2);
            ROIDT  = 1;
        case 'Rectangle'
            h = imrect(gca,[]);
            setColor(h,ln_color);
            ROImsk = createMask(h);
            ROIpos = round(getPosition(h));
            ROIx   = [ROIpos(:,1), ROIpos(:,1) + ROIpos(:,3),  ROIpos(:,1) + ROIpos(:,3),  ROIpos(:,1), ROIpos(:,1)];
            ROIy   = [ROIpos(:,2), ROIpos(:,2),  ROIpos(:,2) + ROIpos(:,4),  ROIpos(:,2) + ROIpos(:,4), ROIpos(:,2)];
            ROIDT  = 1;
        case 'Ellipse'
            h = imellipse(mapH,[]);
            setColor(h,ln_color);
            ROImsk = createMask(h);
            ROIpos = round(getPosition(h));
            ROIx   = 0;
            ROIy   = 0;
            ROIDT  = 0;
        case 'Polygon'
            h = impoly(gca,[]);
            setColor(h,ln_color);
            ROImsk = createMask(h);
            ROIpos = round(getPosition(h));
            ROIx   = [ROIpos(:,1); ROIpos(1,1)];
            ROIy   = [ROIpos(:,2); ROIpos(1,2)];
            ROIDT  = 1;
        case 'Freehand'
            h = imfreehand(gca);
            setColor(h,ln_color);
            ROImsk = createMask(h);
            ROIpos = round(getPosition(h));
            ROIx   = [ROIpos(:,1); ROIpos(1,1)];
            ROIy   = [ROIpos(:,2); ROIpos(1,2)];
            ROIDT  = 1;
        otherwise
            h = impoint(ima,[]);
            setColor(h,ln_color);
            ROImsk = createMask(h);
            ROIpos = round(getPosition(h));
            ROIx   = ROIpos(:,1);
            ROIy   = ROIpos(:,2);
            ROIDT  = 1;
    end,
    ROIsPOS{roi_idx} = ROIpos;
    ROIsMSK{roi_idx} = ROImsk;
    ROIsX  {roi_idx} = ROIx;
    ROIsY  {roi_idx} = ROIy;
    ROIsDTN{roi_idx} = ROIDT;
end;

return;
