function save_EMC_results(fn,UD)

EMC_results = UD.EMC_results;       %#ok<*NASGU>
slices_loc  = UD.slices_loc;
save(fn,'UD'         ,...
        'EMC_results',...
        'slices_loc');
	
return;

