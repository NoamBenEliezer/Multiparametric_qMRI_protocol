% sim_T2_arr      |  [sec]  | vector
% firstTE         |  [sec]  | scalar
% min_T2distance  |  [a.u.] | scalar  - minimal distance in indices allowed between two adjacant T2 components
% precision       |  [a.u.] | integer - round number to certain number of digits after the decimal point

function st = set_brute_force_3_T2_comp_SEMC_fit_struct(Nx, Ny, im_SE_MC, nB0, nB1, nT1, nT2, ETL, firstTE, fit_sig_th, ...
                                        min_N_echoes, opt_flag, sim_EchoModulation_mat, sim_B0_arr, ...
                                        sim_B1_arr, sim_T1_arr, sim_T2_arr, B1_idxs, T21_idxs, T22_idxs, T23_idxs,...
                                        min_T2distance,precision)

st.Nx                      = Nx;                       % 1
st.Ny                      = Ny;                       %
st.im_SE_MC                = im_SE_MC;                 %
st.nB0                     = nB0;                      %
st.nB1                     = nB1;                      % 5
st.nT1                     = nT1;                      %
st.nT2                     = nT2;                      %
st.ETL                     = ETL;                      %
st.firstTE                 = firstTE;                  %    [sec]
st.fit_sig_th              = fit_sig_th;               % 10
st.min_N_echoes            = min_N_echoes;             % 
st.opt_flag                = opt_flag;                 %
st.sim_EchoModulation_mat  = sim_EchoModulation_mat;   % 
st.sim_B0_arr              = sim_B0_arr;               % 
st.sim_B1_arr              = sim_B1_arr;               % 15
st.sim_T1_arr              = sim_T1_arr;               % 
st.sim_T2_arr              = sim_T2_arr;               %    [sec]
st.B1_idxs                 = B1_idxs;                  % 
st.nB1_idxs                = length(B1_idxs);          % 
st.T21_idxs                = T21_idxs;                 % 20
st.nT21_idxs               = length(T21_idxs);         % 
st.T22_idxs                = T22_idxs;                 % 
st.nT22_idxs               = length(T22_idxs);         % 
st.T23_idxs                = T23_idxs;                 % 
st.nT23_idxs               = length(T23_idxs);         % 25
st.min_T2distance          = min_T2distance;           %
st.precision               = precision;                % 27

return;

