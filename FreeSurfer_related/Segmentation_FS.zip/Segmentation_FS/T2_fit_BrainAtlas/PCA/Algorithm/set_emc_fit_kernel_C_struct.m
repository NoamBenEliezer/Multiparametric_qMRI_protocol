
% Prepare structure for 'evolve_M_CPP' C function
% See the function documentation for parameters description.
function  st = set_emc_fit_kernel_C_struct(Nx, Ny, im_SE_MC, nB0, nB1, nT1, nT2, ETL,fit_sig_th,...
                                           min_N_echoes,opt_flag,sim_EchoModulation_mat, sim_B0_arr,...
                                           sim_B1_arr, sim_T1_arr, sim_T2_arr,inB1map,B1constraint_mrgn)

st.Nx                      = Nx;                       % 1
st.Ny                      = Ny;                       % 2
st.im_SE_MC                = im_SE_MC;                 % 3
st.nB0                     = nB0;                      % 4
st.nB1                     = nB1;                      % 5
st.nT1                     = nT1;                      % 6
st.nT2                     = nT2;                      % 7
st.ETL                     = ETL;                      % 8
st.fit_sig_th              = fit_sig_th;               % 9
st.min_N_echoes            = min_N_echoes;             % 10
st.opt_flag                = opt_flag;                 % 11
st.sim_EchoModulation_mat  = sim_EchoModulation_mat;   % 12
st.sim_B0_arr              = sim_B0_arr;               % 13
st.sim_B1_arr              = sim_B1_arr;               % 14
st.sim_T1_arr              = sim_T1_arr;               % 15
st.sim_T2_arr              = sim_T2_arr;               % 16
st.inB1map                 = inB1map;                  % 17
st.B1constraint_mrgn       = B1constraint_mrgn;        % 18

return;

