
function [B1Fit_S_Cal,B1idx_map] = emc_smooth_B1(im,T2,B1,B1_val_arr,FirstTE,ETL)

smoothnessVal       = max([5, ceil(mean(size(im))/15)]);   % Set the smoothness kernel at ~7% of the average image dimensions
th                  = 0.1;

% Exclude regions with very low or very high T2 values. These are "hard to fit" and thus cause bias in the
% initial B1 map. B1 values in these regions are therefore not to be trusted.
% T2l                 = FirstTE / 4;           % WM-only: 45
% T2h                 = FirstTE*ETL*5;     % WM-only: 70

T2l                 = 10;           % WM-only: 45
T2h					= 200;

erode_nPx           = 0;    % 0 might be the best in this case...
                            % Notice the effec that this parameter has on the output map.
                            % Look carefully for B1 areas that does not seem to be extrapolated correctly.
							
th_of_nPx_in_slice  = 0.3;  % [0...1] Default: 0.3. Relative fraction of pixels in a slice to allow interpolation
chauvenet_criterion = 2;    % Remove outliers using Chauvenet's criterion

plot_f              = 0;

% %% I. Load files and set parameters
% if nargin == 0
% addpath('/Users/noambe/Dropbox/EMC_T2_FIT/Algorithm/smooth_B1_constraint/vistasoft-master/mrAnatomy/hydrationLayer');
% tmp = load('/Users/noambe/Dropbox/EMC_T2_FIT/EMC_Results/SEMC149_EMC_fit_Result.mat');
% 
% im = tmp.EMC_results.Original_image(:,:,1);
% T2 = tmp.EMC_results.T2map_SEMC * 1e3;
% B1 = tmp.EMC_results.B1map_SEMC;
% PD = tmp.EMC_results.PDmap_SEMC;
% B1_val_arr = 0.5:0.01:1.3;
% end;

%% Chauvenet's criterion
if (chauvenet_criterion)
	B1mean = mean(B1(B1~=0));
	B1SD   =  std(B1(B1~=0));
	B1(B1 < (B1mean - chauvenet_criterion*B1SD)) = 0;
	B1(B1 > (B1mean + chauvenet_criterion*B1SD)) = 0;
	B1_mask = logical(B1);
end;

% Convolution with a low pass filter -- this is not an optimal solution.
% It cannot ignore 0 valued pixels as gridfit does.
% % conv_mat = [1 1 1 ; 1 -8 1 ; 1 1 1];
% conv_mat = [1 1 1 ; 1 1 1 ; 1 1 1]/9;
% % B1_mean  = mean(B1msked(B1msked~=0))*0;
% B1_conv  = conv2(B1,conv_mat,'same'); % + B1_mean);% .* B1msked;
% B1_conv(B1==0) = 0;
% % B1_conv(B1_conv < 0.8) = 0;
% % B1_conv(B1_conv > 1.2) = 0;
% % figure;
% % subplot(121); imagesc(B1     ); ai; colorbar; caxis([0.7 1.1]);
% % subplot(122); imagesc(B1_conv); ai; colorbar; caxis([0.7 1.1]);
% % B1 = B1_conv;
% % return;


%%
im_mask = create_mask(im,th);
PD_mask = ones(size(im));     % create_mask(PD,th); This function is called when PD has not yet been calculated.
                              %                     Still, PD mask does not seem to have a large effect on the result
							  %                     so skip using it for now.
T2_mask = ones(size(T2));
T2_mask(T2 <= T2l) = 0;
T2_mask(T2 >= T2h) = 0;
T2_mask = logical(T2_mask);

% im_mask = erode_2D_mat(im_mask,erode_nPx);
% PD_mask = erode_2D_mat(PD_mask,erode_nPx);
% T2_mask = erode_2D_mat(T2_mask,erode_nPx);

mask     = logical(T2_mask.*im_mask.*PD_mask);
mask_erd = erode_2D_mat(mask,erode_nPx);
mask_erd = logical(mask_erd);

B1msked = B1.*mask_erd;

%%
% figure;
% subplot(221); imagesc(B1     ); ai; colorbar; caxis([0.9 1.10]);
% subplot(222); imagesc(B1msked); ai; colorbar; caxis([0.9 1.10]);
% subplot(223); imagesc(T2     ); ai; colorbar; caxis([0   200 ]);
% subplot(224); imagesc(T2_mask); ai; colorbar;
% return;

B1Fit_S = B1msked;


%% IIa. Loop over Z slices

[XI YI]=meshgrid(1:size(B1Fit_S,1),1:size(B1Fit_S,2));

for idx=1:size(B1Fit_S,3)
	
	tmp=B1Fit_S(:,:,idx);
	
	% Check that there is data in the slice
	wh=find(tmp>0);
	length(find(tmp>0))/length(tmp(:))
	if ((length(find(tmp>0))/length(tmp(:)) > th_of_nPx_in_slice) && length(wh)>1000)
		
		% find location of data
		[x,y] = ind2sub(size(tmp),wh);
		z=double(tmp(wh));
		
		% Estimate a smooth version of the data in the slice
		%
		% (For original code, see:
		%     Noterdaeme et al.
		%     "Intensity correction with a pair of spoiled gradient
		%       recalled echo images".
		%     Phys. Med. Biol. 54 3473-3489 (2009)
		%                                         )
		
		[zg,xg,yg]= gridfit(x,y,z,1:2:size(tmp,1),1:2:size(tmp,2),'smoothness',smoothnessVal);
		ZI = griddata(xg,yg,zg,XI,YI);
		
		if  ~isempty(find(isnan(ZI),1)) % We might get NaNs in the edges
			ZIt = griddata(xg,yg,zg,XI,YI,'v4');
			ZI(isnan(ZI))=ZIt(isnan(ZI));
		end
		
		% Put the resulting gain in the 3D gain image and fix the orientation
		ZI=rot90(ZI);
		ZI = flipdim(ZI,1);
		B1Fit_S(:,:,idx)=ZI;
		
		clear ZI
	end;

end;
B1Fit_S(B1Fit_S<0)=0;


%% IIb. Loop over X slices

[XI YI]=meshgrid(1:size(B1Fit_S,2),1:size(B1Fit_S,3));

for idx=1:size(B1Fit_S,1)
	
	tmp=squeeze(B1Fit_S(idx,:,:));
	
	%check that there is data in the slice
	wh=find(tmp>0);
	if ((length(find(tmp>0))/length(tmp(:)) > th_of_nPx_in_slice) && ...
	    (length(find(tmp>0))/length(tmp(:)) < 1                 ) && ...
		length(wh)>1000)
		
		%find location of data
		[x,y] = ind2sub(size(tmp),wh);
		z=double(tmp(wh));
		% estimate a smooth version of the data in the slice
		
		[zg,xg,yg]= gridfit(x,y,z,1:2:size(tmp,1),1:2:size(tmp,2),'smoothness',smoothnessVal);
		ZI = griddata(xg,yg,zg,XI,YI);
		if ~isempty(find(isnan(ZI),1)) % we might get nan in the edges
			ZIt = griddata(xg,yg,zg,XI,YI,'v4');
			ZI(isnan(ZI))=ZIt(isnan(ZI));
		end
		% Put the resulting gain in the 3D gain image and fix the orientation
		ZI=rot90(ZI);
		ZI = flipdim(ZI,1);
		B1Fit_S(idx,:,:)=ZI;
		
		clear ZI
	end;
	
end;
B1Fit_S(B1Fit_S<0)=0;


%% IIc. Loop over Y slices

[XI YI]=meshgrid(1:size(B1Fit_S,1),1:size(B1Fit_S,3));

for idx=1:size(B1Fit_S,2)
	
	tmp=squeeze(B1Fit_S(:,idx,:));
	
	%check that there is data in the slice
	wh=find(tmp>0);
	if ((length(find(tmp>0))/length(tmp(:)) > th_of_nPx_in_slice) && ...
	    (length(find(tmp>0))/length(tmp(:)) < 1                 ) && ...
	    length(wh)>1000)
		
		%find location of data
		[x,y] = ind2sub(size(tmp),wh);
		z=double(tmp(wh));
		% estimate a smooth version of the data in the slice
		
		[zg,xg,yg]= gridfit(x,y,z,1:2:size(tmp,1),1:2:size(tmp,2),'smoothness',smoothnessVal);
		ZI = griddata(xg,yg,zg,XI,YI);
		
		if  ~isempty(find(isnan(ZI),1)) % we might get NaNs in the edges
			ZIt = griddata(xg,yg,zg,XI,YI,'v4');
			ZI(isnan(ZI))=ZIt(isnan(ZI));
		end
		
		% Put the resulting gain in the 3D gain image and fix the orientation
		ZI=rot90(ZI);
		ZI = flipdim(ZI,1);
		B1Fit_S(:,idx,:)=ZI;
		
		clear ZI
	end;
	
end;
B1Fit_S(B1Fit_S<=0)=0;

%% III. Calculate if the smoothing introduces a constant bias, and correct for it.

% Original bias clearing (from mrQ_smooth_LR_B1.m)
mask(B1Fit_S==0) = 0;

mask(isnan(B1(:) ./ B1Fit_S(:))) = 0;
mask(isinf(B1(:) ./ B1Fit_S(:))) = 0;

Cal         = median(B1(mask) ./ B1Fit_S(mask));
B1Fit_S_Cal = B1Fit_S.*Cal;

% B1Fit_S(B1Fit_S<=0)=1;
% B1Fit_S(isnan(B1Fit_S))=1;
% B1Fit_S(isinf(B1Fit_S))=1;

B1Fit_S_Cal(B1Fit_S_Cal  <=0  ) = 0;
B1Fit_S_Cal(isnan(B1Fit_S_Cal)) = 0;
B1Fit_S_Cal(isinf(B1Fit_S_Cal)) = 0;

B1Fit_S_Cal = round(100*B1Fit_S_Cal)/100;

%% IV
if exist('B1_val_arr','var')
	for ix = 1:size(B1Fit_S_Cal,1)
	for iy = 1:size(B1Fit_S_Cal,2)
		val = B1Fit_S_Cal(ix,iy);
		[~,idx] = min(abs(B1_val_arr-val));
		B1idx_map(ix,iy) = idx;
	end;
	end;
else
	B1idx_map = 0;
end;


%% Plot
if (plot_f)
% idx = 0; m=1; n=3; ca=[0.7 1.1];
% figure;
% idx=idx+1; subplot(m,n,idx); imagesc(B1         .*mask   ); ai; caxis(ca); title('B1   '); colorbar;
% idx=idx+1; subplot(m,n,idx); imagesc(B1Fit_S_Cal.*mask   ); ai; caxis(ca); title('B1Fit S Cal'); colorbar;
% idx=idx+1; subplot(m,n,idx); imagesc(mask                ); ai;            title('mask       ');

idx = 0; m=1; n=3; ca=[0.7 1.1];
figure;
idx=idx+1; subplot(m,n,idx); imagesc(B1         .*im_mask.*PD_mask); ai; caxis(ca); title('B1   '); colorbar;
idx=idx+1; subplot(m,n,idx); imagesc(B1Fit_S_Cal.*im_mask.*PD_mask); ai; caxis(ca); title('B1Fit S Cal'); colorbar;
idx=idx+1; subplot(m,n,idx); imagesc(mask_erd                     ); ai;            title('mask       ');

% idx = 0; m=3; n=2; ca=[0.9 1.1];
% figure;
% idx=idx+1; subplot(m,n,idx); imagesc(B1msked    ); ai; caxis(ca); title('B1 masked  '); colorbar;
% idx=idx+1; subplot(m,n,idx); imagesc(mask       ); ai;            title('Mask       '); colorbar;
% idx=idx+1; subplot(m,n,idx); imagesc(B1Fit_S    ); ai; caxis(ca); title('B1Fit S    '); colorbar;
% idx=idx+1; subplot(m,n,idx); imagesc(B1Fit_S_Cal); ai; caxis(ca); title('B1Fit S Cal'); colorbar;
% idx=idx+1; subplot(m,n,idx); imagesc(T2*1e3     ); ai; caxis([0 200]); title('T2 [ms]    '); colorbar;
% idx=idx+1; subplot(m,n,idx); imagesc(PD      ); ai;  title('PD mask'); colorbar;
end;

return;


