function tickoff()

set(gca,'XTick',[],'YTick',[]);