tic;
clear all;

addpath(genpath('.../T2_fit_BrainAtlas/PCA'));

ws_list = [5];
num_of_slices = 32;
NEchoes = 12;


All_data_path='.../T2_fit_BrainAtlas/Brain_Atlas';

%% Run all volunteers
dir_list=dir(All_data_path);
count=0;
for vol_idx=1:length(dir_list)
if dir_list(vol_idx).name(1)=='V'
    count=count+1;
        Volunteer_list{count}=dir_list(vol_idx).name;
end
end

for vol_idx=1:length(Volunteer_list)
vol_dir= dir([All_data_path filesep Volunteer_list{vol_idx}]);

if length (vol_dir)>4 % Skip if already perforemed denoising
    continue;
end
vol_ID=Volunteer_list{vol_idx};
raw_data_path = [All_data_path filesep vol_ID]; % raw data location

Data_dir=dir(raw_data_path);

for i=1:length (Data_dir)
%     Data_dir(i).name
    if Data_dir(i).name(1)~='.'
        if Data_dir(i).isdir
            DCM_folder=Data_dir(i).name;
        else
            dat_name=Data_dir(i).name;
        end        
    end   
end
clear Data_dir

DCM_path=[raw_data_path filesep DCM_folder];
tmp_dcm=dir(DCM_path);
tmp_dcm=tmp_dcm(5).name;
tmp_dcm=dicomread([DCM_path filesep tmp_dcm]);
Nx = size(tmp_dcm,1); %?
Ny = size(tmp_dcm,2);%?
clear tmp_DCM 


%MESE
% 	dat_name = 'meas_MID00024_FID30188_se_mc_NBE_Brain_Atlas'; % raw data name
	result_mat_file = sprintf('MESE_denoised_%s',vol_ID);
	result_mat_file(end+1:end+4) = '.mat';


is_save_unnorm = 1;
opts.noise_denoise = 1; % apply PCA denoising
result_3d_mat_den = zeros(num_of_slices,Nx,Ny,NEchoes);
result_3d_mat_org = zeros(num_of_slices,Nx,Ny,NEchoes);

for window_size = ws_list
    for slice_number = 1:num_of_slices
		window = [window_size window_size];

        %MESE
			[~, ~, ~, org_unnorm, img_after_complex_pca_unnorm] = reconstruct_images_from_raw_data(raw_data_path, dat_name, opts, window, [], slice_number, []);
       
		if (is_save_unnorm)
% 			output_file_full_path = sprintf(strrep(['/home/netastern/PCA/brain_1_desnoised_images/Brain_1_SL' num2str(slice_number) '_unnorm_img_after_complex_pca_ws_%d'],'\','\\'), window_size);
			disp(size(img_after_complex_pca_unnorm));
			result_3d_mat_den(slice_number,:,:,:) = img_after_complex_pca_unnorm;
            result_3d_mat_org(slice_number,:,:,:) = org_unnorm;
% 	 		output_file_full_path = sprintf(strrep(['/home/netastern/PCA/brain_1_desnoised_images/Brain_1_SL' num2str(slice_number) '_unnormalized_org_complex_img'],'\','\\'));
        end
    end
    
%     save([raw_data_path filesep 'DATV032_result_3d_mat_org.mat'], 'result_3d_mat_org');
    save([raw_data_path filesep sprintf('DAT_%s_result_3d_mat_denoised_ws_%d.mat',vol_ID,window_size)], 'result_3d_mat_den');
end

% for idxSl=1:size(result_3d_mat_den,1)
%     for idxEcho=1:size(result_3d_mat_den,4)
%         A=rot90(squeeze(result_3d_mat_den(idxSl,:,:,idxEcho)),3);
%         Denoised_maps(1:size(A,1), 1:size(A,2), idxEcho, idxSl)=A; 
%     end
% end
% 
% 
% save([raw_data_path result_mat_file], 'Denoised_maps');

toc
end


% disp (sprintf('Done processing MP-PCA denoising for vol #%d',vol_ID));



