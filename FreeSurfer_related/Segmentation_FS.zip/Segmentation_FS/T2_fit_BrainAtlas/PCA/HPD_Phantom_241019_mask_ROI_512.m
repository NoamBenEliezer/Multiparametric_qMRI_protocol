function [centers, ROI_radius] = HPD_Phantom_241019_mask_ROI_512()
	% [NS] resolution 512, HPD phantom 24/10/19
	Tube{1}=[308,102];    % 
	Tube{2}=[387,158];    % 
	Tube{3}=[423,252];     % 
	Tube{4}=[388,346];     %
	Tube{5}=[312,406];    % 
	Tube{6}=[214,406];    % 
	Tube{7}=[133,349];     % 
	Tube{8}=[99,259];     % 
	Tube{9}=[130,163];     % 
	Tube{10}=[209,102];     %  
	Tube{11}=[196,190];     % 
	Tube{12}=[326,189];     % 
	Tube{13}=[323,318];     %
	Tube{14}=[197,320];     %
	ROI_radius = 25;

	centers = [];
	%% Centers
	for Tube_idx=1:numel(Tube)
		centers=[centers (Tube{Tube_idx})'];    
	end
end

