%#ok<*AGROW>

function [orig_im_series, recon_im_series_norm, im_after_complex_pca_norm, recon_im_series_unnorm, im_after_complex_pca_unnorm, last_P_map] = ...
	Neta_reconstruct_images_from_raw_data(SEMCDataDir, dat_fname, opts, window, snr, slice_number, pca_mask)

remove_ROOS           = 1;        % Remove readout oversampling
use_refscan_data_flag = 1;        % Incorporate reference scan data in final image
grappa_kernel_size    = [6,5];    % Original [4,3]. [6,5] works best. [8,5] starts introducing artifacts.
dicom_mask_threshold  = 0.03;     % Exclude image pixels below a certain threshold

if ~(exist('opts','var'))
	opts.noise_denoise = 0;
end

res_fn_orig = [dat_fname(1:end-4) '_processed_for_DICOMs.mat'];  % Save the processed .dat file matlab environment
data_path  = SEMCDataDir;

% ## Read the data from the Siemens TWIX file
twix_obj=mapVBVD([data_path filesep dat_fname]);

% [nbe]
if (length(twix_obj) == 1)
	clear tmp;
	tmp{1} = [];
	tmp{2} = twix_obj;
	twix_obj = tmp;
	clear tmp;
end;

% Read the sequence parameters from the file
Nx      = double(twix_obj{2}.image.NCol);
Ny      = double(twix_obj{2}.image.NLin);
fprintf('Nx: %d Ny: %d',Nx, Ny);
NCha    = double(twix_obj{2}.image.NCha);
NSli    = double(twix_obj{2}.image.NSli);
NEco    = double(twix_obj{2}.image.NEco);
slc_loc1= double(twix_obj{2}.image.slicePos(2,:));
for is = 1:NSli
	slc_loc(is) = slc_loc1((is-1)*NEco + 1);
end


% Get the k-space data
kspc_data = twix_obj{2}.image{''};   % [NBE] use image() to get full data or image{} to get squeezed data.
kspc_data = kspc_data(:,:,:,[1:2:NSli 2:2:NSli],:,:); % [NS - Reorder slices; need to check that this is correct for Dvir' scans]
% kspc_data = squeeze(kspc_data);

if (NSli == 1)
kspc_data = permute(kspc_data,[3,1,2,4,5]);        % organize as [1,Ny,Nx,Nc,Contrasts,Segments]
% tmp = zeros([1 size(kspc_data)]);
tmp(1,:,:,:,:,:) = kspc_data;
kspc_data = tmp;
clear tmp;
else
% TODO: DELETE!!! 
kspc_data = kspc_data(:,:,:,slice_number,:,:);
kspc_data = permute(kspc_data,[4,3,1,2,5,6]);      % organize as [Slice,Ny,Nx,Nc,Contrasts,Segments]
end;

% Calculate the acceleration factor
tmp      = abs(squeeze(kspc_data(1,:,1,1,1,1)));        % extract a single k-space line along PE dimension
af       = round(length(tmp) / length(tmp(tmp==0)));    % acceleration = #-of-datapoints / #-of-skipped-datapoints
disp('af:\n');
disp(length(tmp) / length(tmp(tmp==0)));

% No acceleration will translate to inf
if (af > 1) && (af < 20)
	% Get the reference k-space data
	refs_data = twix_obj{2}.refscan();
	refs_data = squeeze(refs_data);

	if (NSli == 1)
	refs_data = permute(refs_data,[3,1,2,4,5]);
	tmp = zeros([1 size(refs_data)]);
	tmp(1,:,:,:,:,:) = refs_data;
	refs_data = tmp;
	clear tmp;
	else
	refs_data = refs_data(:,:,:,slice_number,:,:);
	refs_data = permute(refs_data,[4,3,1,2,5,6]);      % organize as [Slice,Ny,Nx,Nc,Contrasts,Segments]
	end;
else
	af = 0;
end;


% Call the GRAPPA reconstrunction function

for is = 1 %:NSli	
for ie = 1:NEco
% 	fprintf('------------------------------------------------------\n');
	fprintf('Processing Slice #%1.0f (%1.0f), Echo Time #%1.0f (%1.0f)\n',slice_number,NSli,ie,NEco);
% 	fprintf('------------------------------------------------------\n');
	
	if (af > 1)
		kspc_data_ie = squeeze(kspc_data(is,1:af:end,:,:,ie,ie));   % Choose echo time and remove empty lines
		refs_data_ie = squeeze(refs_data(is,    :   ,:,:,ie,ie));

%		% For some unknown reason this sometime causes aliasing or small artifacts in the RO dimension.
%		% This doesn't make sense... Needs to be resoleved at some point to accelerate the reconstruction!
% 		if (remove_ROOS)
% 			kspc_data_ie = kspc_data_ie(:,1:2:Nx,:);
% 			refs_data_ie = refs_data_ie(:,1:2:Nx,:);
% 		end;

		% No need to differentiate between kernel size 4x3 and other sizes. Use the same general function for all.
% 		if (grappa_kernel_size == [4,3])
% 		recon_kSpace = grappa4x3(kspc_data_ie,refs_data_ie,af,use_refscan_data_flag);
% 		res_fn = sprintf('%s_GRAPPAkernel%1.0fx%1.0f_auto.mat'  ,res_fn_orig(1:end-4),grappa_kernel_size(1),grappa_kernel_size(2));
% 		else
		recon_kSpace = grappa1_2d(kspc_data_ie,refs_data_ie,af,grappa_kernel_size,use_refscan_data_flag);
		res_fn = sprintf('%s_GRAPPAkernel%1.0fx%1.0f_manual.mat',res_fn_orig(1:end-4),grappa_kernel_size(1),grappa_kernel_size(2));
% 		end;
		
	else
		kspc_data_ie = squeeze(kspc_data(is,:,:,:,ie,ie));		
		recon_kSpace = kspc_data_ie;
		res_fn = sprintf('%s_unaccelerated.mat',res_fn_orig(1:end-4));
	end;
	
	% Sum of square the channels
	orig_im  = 0;
	recon_im = 0;
	for ic = 1:NCha
		tmp_comp   = squeeze(kspc_data_ie(:,:,ic));
		tmp_im   = abs(fftshift(fft2(fftshift(tmp_comp))));
		orig_im = orig_im + abs(tmp_im .* conj(tmp_im));

		tmp_comp   = squeeze(recon_kSpace(:,:,ic));
		tmp_comp   = (fftshift(fft2(fftshift(tmp_comp))));
		recon_complex_series(is,:,:,ie,ic) = tmp_comp;
		tmp_im	   = abs(tmp_comp);
		recon_im = recon_im + abs(tmp_im .* conj(tmp_im));
	end;
	orig_im  = sqrt(orig_im);
	recon_im = sqrt(recon_im);
	
	if (remove_ROOS)
		orig_im  = orig_im (:,(Nx/4+1):(3*Nx/4),:);
		recon_im = recon_im(:,(Nx/4+1):(3*Nx/4),:);
	end;
% 	figure; imagesc(recon_im); ai; ca=caxis; caxis(ca/2);
% 	figure; subplot(211); imagesc(orig_im); ai; ca=caxis; caxis(ca/1); subplot(212); imagesc(recon_im); ai; caxis(ca/1);

	orig_im_series (is,:,:,ie) = orig_im;
	recon_im_series(is,:,:,ie) = recon_im;
end;
end;

pixels_count = (Nx/2) * Ny;

if (opts.noise_denoise > 0)
	tic;
	parfor ic = 1:NCha
		curr_complex_image = squeeze(recon_complex_series(1,:,:,:,ic));
		
		if (opts.noise_denoise == 1)
			if ~isempty(pca_mask)
				[curr_complex_image, ~, last_P_map] = denoiseCV(curr_complex_image,window,pca_mask);
			else
				[curr_complex_image, ~, last_P_map] = denoiseCV(curr_complex_image,window);
			end
		elseif (opts.noise_denoise == 2)
			noise_vectors = generate_noise_vectors(pixels_count, NEco);
			noise_vectors = reshape(noise_vectors, [Nx/2, Ny, NEco]);
			curr_complex_image = insert_noise_to_complex_signal(snr, curr_complex_image, noise_vectors);
		end
		
		recon_complex_series(1,:,:,:,ic) = curr_complex_image;
	end
	disp('Total MP-PCA time: ---------')
	toc
	disp('----------------------------')
end

for ie = 1:NEco
	recon_im = 0;
	
	for ic = 1:NCha
		tmp_comp = squeeze(recon_complex_series(1,:,:,:,ic));
		tmp_im	 = abs(tmp_comp);
		recon_im = recon_im + abs(tmp_im .* conj(tmp_im));
	end
	
	recon_im = sqrt(recon_im);
end

im_after_complex_pca_unnorm = squeeze(recon_im(:,(Nx/4+1):(3*Nx/4),:));
im_after_complex_pca_norm = normalize_SEMC(im_after_complex_pca_unnorm);
% im_after_complex_pca = permute(im_after_complex_pca,[2,1,3]);
% save(res_fn);


% Save to DICOM
recon_im_series_unnorm = permute(recon_im_series,[1,3,2,4]); % [Slice,Nx,Ny,Nc]

% Create basic mask
% for is = 1:NSli
% for ie = 1:NEco
% 	im = abs(squeeze(recon_im_series_norm(is,:,:,ie)));
% 	ie_th = dicom_mask_threshold*max(im(:));
% 	im(im <  ie_th) = 0;
% 	im(im ~= 0    ) = 1;
% 	recon_im_series_norm_mask(is,:,:,ie) = im;
% end;
% end;

% Normalize
% Nx = size(recon_im_series_norm,2);
% Ny = size(recon_im_series_norm,3);
% for is = 1:NSli
% for ix = 1:Nx
% for iy = 1:Ny
% % 	recon_im_series_norm(is,ix,iy,:) = abs((recon_im_series_norm(is,ix,iy,:)) /     abs(recon_im_series_norm(is,ix,iy,1)));
% 	recon_im_series_norm(is,ix,iy,:) = abs((recon_im_series_norm(is,ix,iy,:)) / max(abs(recon_im_series_norm(is,ix,iy,:))));
% end;
% end;
% end;

recon_im_series_norm = normalize_SEMC(squeeze(recon_im_series_unnorm));

% % Plot normalized series of images
% figure; for ie = 1:NEco,  imagesc(squeeze(recon_im_series_norm(:,:,ie))); ai; colorbar; caxis([0 1]); pause(0.5); end;
% figure; for ie = 1,  imagesc(squeeze(recon_im_series_norm(:,:,ie))); ai; colorbar; caxis([0 1]); pause(0.5); end;

% Save the DICOMs
% cur_pwd = pwd;
% DICOM_path = data_path; %[data_path filesep 'DICOMs'];
% if ~isdir(DICOM_path)
% 	mkdir(DICOM_path);
% end;
% cd(DICOM_path);
% 
% dcm_info = dicominfo(dcm_info_fn);
% 
% for is = 1:NSli
% for ie = 1:NEco
% % 	dcm_fn = sprintf('%s_TE%02.0f.dcm',dat_fname(1:end-4),ie);
% 	dcm_fn = sprintf('Reconstructed_dcm_Sl%1.3f_TE%02.0f.dcm',slc_loc(is),ie);
% 	dcm_data = 4092*squeeze(recon_im_series_norm(is,:,:,ie));
% 	dcm_data = dcm_data .* squeeze(recon_im_series_norm_mask(is,:,:,ie));
% % 	dcm_data = fliplr((dcm_data);
% % 	dcm_data = dcm_data((Nx/4+1):(3*Nx/4),:);
% % 	dcm_data = rot90(dcm_data,3);
% 	dicomwrite(uint16(round(dcm_data)),dcm_fn, 'ObjectType','MR Image Storage', 'WritePrivate',true, ...
% 			   dcm_info,...
% 			   'Private_0029_1020',dcm_info.Private_0029_1020,...
% 			   'PixelBandwidth'   ,dcm_info.PixelBandwidth   ,...
% 			   'SliceLocation'    ,slc_loc(is));
% % 			   'SliceLocation'    ,dcm_info.SliceLocation);
% end;
% end;
% cd(cur_pwd);


%% Plot
% figure;
% for ie = 1:NEco
% imagesc(dicomread(sprintf('/Users/noambe/Dropbox/EMC_T2_FIT/DICOMS/SEMC931_mine/meas_MID931_se_mc_RFnorm_FID178692_TE%1.0f.dcm',ie))); ai;
% caxis([0 1e4]);
% pause(0.5);
% end;

% figure; 
% for ie = 1:NEco
% 	subplot(121); imagesc(squeeze(orig_im_series (:,:,ie))); ai; % colorbar;
% 	title(sprintf('Original       [TE #%1.0f]',ie)); caxis([0 0.03]);
% 	subplot(122); imagesc(squeeze(recon_im_series(:,:,ie))); ai; % colorbar;
% 	title(sprintf('Reconstructed  [TE #%1.0f]',ie)); caxis([0 0.09]);
% 	pause(0.2);
% end;


return;

