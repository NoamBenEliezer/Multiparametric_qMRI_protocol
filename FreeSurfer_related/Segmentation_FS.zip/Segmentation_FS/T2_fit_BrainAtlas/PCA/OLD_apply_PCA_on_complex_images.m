tic;
clear all;

ws_list = [5 7];
num_of_slices = 32;
Nx = 156;
Ny = 192;
NEchoes = 12;


is_SSE = 0;

raw_data_path = 'C:\Users\Dvir\Downloads\'; % MESE\ or SSE\

if (is_SSE) %SSE
	result_mat_file = 'SSE_after_denoising';
else %MESE
	raw_data_file = 'Copy of meas_MID00105_FID32080_se_mc_NBE_Brain_Atlas_V1.dat';
	result_mat_file = raw_data_file;
	result_mat_file(end - 2:end) = 'mat';
end

is_save_norm = 0;
is_save_unnorm = 1;
opts.noise_denoise = 1; % apply PCA denoising
result_3d_mat_den = zeros(num_of_slices,Nx,Ny,NEchoes);
result_3d_mat_org = zeros(num_of_slices,Nx,Ny,NEchoes);

for slice_number = 1:num_of_slices
	for window_size = ws_list
		window = [window_size window_size];
		
        if (is_SSE)
			[~, ~, ~, org_unnorm, img_after_complex_pca_unnorm] = SSE_reconstruct_images_from_raw_data(raw_data_path, opts, window, [], slice_number, []);
        else %MESE
			[~, ~, ~, org_unnorm, img_after_complex_pca_unnorm] = Neta_reconstruct_images_from_raw_data(raw_data_path, raw_data_file, opts, window, [], slice_number, []);
        end
        
		if (is_save_unnorm)
% 			output_file_full_path = sprintf(strrep(['/home/netastern/PCA/brain_1_desnoised_images/Brain_1_SL' num2str(slice_number) '_unnorm_img_after_complex_pca_ws_%d'],'\','\\'), window_size);
			disp(size(img_after_complex_pca_unnorm));
			result_3d_mat_den(slice_number,:,:,:) = img_after_complex_pca_unnorm;
            result_3d_mat_org(slice_number,:,:,:) = org_unnorm;
% 	 		output_file_full_path = sprintf(strrep(['/home/netastern/PCA/brain_1_desnoised_images/Brain_1_SL' num2str(slice_number) '_unnormalized_org_complex_img'],'\','\\'));
% 			save(output_file_full_path, 'org_complex_unnorm');
        end
        
        
	end
end

% for idxSl=1:size(result_3d_mat_den,1)
%     for idxEcho=1:size(result_3d_mat_den,4)
%         A=rot90(squeeze(result_3d_mat_den(idxSl,:,:,idxEcho)),3);
%         Denoised_maps(1:size(A,1), 1:size(A,2), idxEcho, idxSl)=A; 
%     end
% end
% 
% 
% save([raw_data_path result_mat_file], 'Denoised_maps');


toc






