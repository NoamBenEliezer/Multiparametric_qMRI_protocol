%%%%%% with SSE %%%%%
tic;
clear all;

ws_list = [5];
num_of_slices = 8;
Nx = 156;
Ny = 192;
NEchoes = 7;

is_SSE = 1;

raw_data_path = 'C:\Users\NetaS\Google Drive\Neta_Stern\PCA_denoising\DATA_DVIR\SSE\';

if (is_SSE)
	result_mat_file = 'SSE_after_denoising';
else
	raw_data_file = 'meas_MID00447_FID80950_MESE_SSE_like.dat';
	result_mat_file = raw_data_file;
	result_mat_file(end - 2:end) = 'mat';
end

is_save_norm = 0;
is_save_unnorm = 1;
opts.noise_denoise = 1; % apply PCA denoising
result_3d_mat = zeros(num_of_slices,Nx,Ny,NEchoes);

for slice_number = 1:num_of_slices
	for window_size = ws_list
		window = [window_size window_size];
		
		if (is_SSE)
			[~, ~, ~, ~, img_after_complex_pca_unnorm] = SSE_reconstruct_images_from_raw_data(raw_data_path, opts, window, [], slice_number, []);
		else
			[~, ~, ~, ~, img_after_complex_pca_unnorm] = Neta_reconstruct_images_from_raw_data(raw_data_path, raw_data_file, opts, window, [], slice_number, []);
		end

		if (is_save_norm)
			output_file_full_path = sprintf(strrep(['/home/netastern/PCA/brain_1_desnoised_images/Brain_1_SL' num2str(slice_number) '_unnorm_img_after_complex_pca_ws_%d'],'\','\\'), window_size);
			save(output_file_full_path, 'img_after_complex_pca');
	 		output_file_full_path = sprintf(strrep(['/home/netastern/PCA/brain_1_desnoised_images/Brain_1_SL' num2str(slice_number) '_unnormalized_org_complex_img'],'\','\\'));
			save(output_file_full_path, 'org_complex');
		end

		if (is_save_unnorm)
% 			output_file_full_path = sprintf(strrep(['/home/netastern/PCA/brain_1_desnoised_images/Brain_1_SL' num2str(slice_number) '_unnorm_img_after_complex_pca_ws_%d'],'\','\\'), window_size);
			disp(size(img_after_complex_pca_unnorm));
			result_3d_mat(slice_number,:,:,:) = img_after_complex_pca_unnorm;
% 	 		output_file_full_path = sprintf(strrep(['/home/netastern/PCA/brain_1_desnoised_images/Brain_1_SL' num2str(slice_number) '_unnormalized_org_complex_img'],'\','\\'));
% 			save(output_file_full_path, 'org_complex_unnorm');
		end
	end
end

save([raw_data_path result_mat_file], 'result_3d_mat');
toc