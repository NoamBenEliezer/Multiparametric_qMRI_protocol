tic;

% clear all;
root_folder = '';
fit_B1_flag = 1;

img_type = ''; % after_complex_PCA\after_PCA\org_complex\org


compile_emc_fit_C_code('/home/netastern/PCA/');


combinations = {{2,380,0,'org_complex'};
				{2,380,5,'after_complex_PCA'};
				{2,380,7,'after_complex_PCA'}};

for curr_comb_idx = 1:length(combinations)
	curr_comb = combinations{curr_comb_idx};
	slice_thickness = curr_comb{1};
	resolution = curr_comb{2};
	ws = curr_comb{3};
	img_type = curr_comb{4}; % after_complex_PCA\after_PCA\org_complex\org
	
	if (slice_thickness == 2)
		db_path = [root_folder '1811_PCA_test_HPD_sl_2_400um_L_20mm_ABS.mat'];
	elseif (slice_thickness == 1)
		db_path = [root_folder '2410_PCA_test_HPD_sl_1_400um_L_20mm_ABS.mat'];
	end

	if strcmp(img_type,'org_complex')
		img_path = [root_folder 'normalized_org_complex_img_slice_thickness_' num2str(slice_thickness) '_res_' num2str(resolution)];
		T2_map_file_name = [root_folder sprintf('Th01_T2_map_complex_%s_slice_thickness_%d_res_%d_isFitB1_%d.mat', img_type, slice_thickness, resolution, fit_B1_flag)];
		B1_map_file_name = [root_folder sprintf('Th01_B1_map_complex_%s_slice_thickness_%d_res_%d_isFitB1_%d.mat', img_type, slice_thickness, resolution, fit_B1_flag)];
		nEchoes_map_file_name = [root_folder sprintf('Th01_nEchoes_map_complex_%s_slice_thickness_%d_res_%d_isFitB1_%d.mat', img_type, slice_thickness, resolution, fit_B1_flag)];
	elseif strcmp(img_type,'org')
		img_path = [root_folder 'normalized_org_img_slice_thickness_' num2str(slice_thickness) '_res_' num2str(resolution)];
		T2_map_file_name = [root_folder sprintf('T2_map_%s_slice_thickness_%d_res_%d_isFitB1_%d.mat', img_type, slice_thickness, resolution, fit_B1_flag)];
		B1_map_file_name = [root_folder sprintf('B1_map_%s_slice_thickness_%d_res_%d_isFitB1_%d.mat', img_type, slice_thickness, resolution, fit_B1_flag)];
		nEchoes_map_file_name = [root_folder sprintf('nEchoes_map_%s_slice_thickness_%d_res_%d_isFitB1_%d.mat', img_type, slice_thickness, resolution, fit_B1_flag)];
	else
		img_path = [root_folder 'img_' img_type '_slice_thickness_' num2str(slice_thickness) '_res_' num2str(resolution) '_ws_' num2str(ws)]; 
		T2_map_file_name = [root_folder sprintf('Th01_T2_map_%s_slice_thickness_%d_res_%d_isFitB1_%d_ws_%d.mat', img_type, slice_thickness, resolution, fit_B1_flag, ws)];
		B1_map_file_name = [root_folder sprintf('Th01_B1_map_%s_slice_thickness_%d_res_%d_isFitB1_%d_ws_%d.mat', img_type, slice_thickness, resolution, fit_B1_flag, ws)];
		nEchoes_map_file_name = [root_folder sprintf('Th01_nEchoes_map_%s_slice_thickness_%d_res_%d_isFitB1_%d_ws_%d.mat', img_type, slice_thickness, resolution, fit_B1_flag, ws)];
	end

	load(db_path);

	emc_db   = echo_train_modulation;
	T1_arr   = T1_tse_arr;         % [sec]
	T2_arr   = T2_tse_arr;         % [sec]
	B1_arr   = B1_scaling_arr;     % [%]
	B0_arr   = B0_scaling_arr;     

	[~,nB1,nT1,nT2,ETL] = size(emc_db);

	% Normalize the emc database
	emc_db = normalize_5D_EMC(emc_db);

	im_SEMC = load(img_path);

	if strcmp(img_type,'org')
		im_SEMC = im_SEMC.im_SEMC_norm;
	elseif strcmp(img_type,'org_complex')
		im_SEMC = im_SEMC.org_complex;
	elseif (strcmp(img_type,'after_complex_PCA'))
		im_SEMC = im_SEMC.img_after_complex_pca;
	else
		im_SEMC = im_SEMC.image_after_pca;
	end

	if ~isa(im_SEMC,'double')
		im_SEMC = double(im_SEMC);
	end

	fit_sig_th             = 0.2;
	min_N_echoes           = 3;
	opt_flag               = 0;

	im_SEMC_norm = normalize_SEMC(im_SEMC);

	if (~fit_B1_flag)
		[~, loc] = min(abs(B1_arr - 1));  % neutral value is 100 [%] = 1 in normalized scale
		emc_db = emc_db(:,loc,:,:,:);
		B1_arr = 1;
	end;

	% TODO
	[~,~, ...
	 fitted_B1_map,~, ...
	 ~,~, ...
	 fitted_T2_map, ...
	 ~, nEchoes_map] = emc_fit_kernel_C_wrapper(im_SEMC_norm(1:300,1:300,:), size(im_SEMC_norm,ndims(im_SEMC_norm)), 0, ...
											emc_db, fit_sig_th, min_N_echoes,opt_flag, B0_arr, ...
											B1_arr, T1_arr, T2_arr);

	save(T2_map_file_name, 'fitted_T2_map');
	save(B1_map_file_name, 'fitted_B1_map');
	save(nEchoes_map_file_name, 'nEchoes_map');
end

time = toc;
hr   = floor(time/3600);
mn   = floor((time - hr*3600)/60);
sc   = round( time - hr*3600 - mn*60);
fprintf('\n ===== Total run time = %2.0f:%2.0f:%2.0f hr:mn:sc\n\n',hr,mn,sc);
