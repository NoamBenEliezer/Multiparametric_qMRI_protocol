clear all;

addpath(genpath('/home/netastern/Siemens/EMC_T2_FIT/'));

% NOTICE: In addition to redefining parameters, DB should be added to DB
% folder in the GUI

combinations = { % {2,100,0,'org_complex'};
% 				{2,192,0,'org_complex'};
% 				{2,256,0,'org_complex'};
% 				{2,380,0,'org_complex'};	
% 				{2,512,0,'org_complex'};
% 				{1,100,0,'org_complex'};
% 				{1,192,0,'org_complex'};
% 				{1,256,0,'org_complex'};
% 				{1,380,0,'org_complex'};
% 				{1,512,0,'org_complex'};
% 				{2,100,5,'after_complex_PCA'};
% 				{2,192,5,'after_complex_PCA'};
% 				{2,256,5,'after_complex_PCA'};
% 				{2,380,5,'after_complex_PCA'};
% 				{1,100,5,'after_complex_PCA'};
% 				{1,192,5,'after_complex_PCA'};
% 				{1,256,5,'after_complex_PCA'};
% 				{1,380,5,'after_complex_PCA'};
% 				{2,100,7,'after_complex_PCA'};
% 				{2,192,7,'after_complex_PCA'};
% 				{2,256,7,'after_complex_PCA'};
% 				{2,380,7,'after_complex_PCA'};
% 				{1,100,7,'after_complex_PCA'};
% 				{1,192,7,'after_complex_PCA'};
% 				{1,256,7,'after_complex_PCA'};
% 				{1,380,7,'after_complex_PCA'};
				{2,512,7,'after_complex_PCA'};
				{1,512,7,'after_complex_PCA'};
				{1,512,5,'after_complex_PCA'};
				{2,512,5,'after_complex_PCA'}};
			
dicom_folder_mapping = [1,100,14;
						1,192,15;
						1,256,16;
						1,380,17;
						1,512,18;
						2,100,19;
						2,192,20;
						2,256,21;
						2,380,22;
						2,512,23];

db_data_root_folder = '/home/netastern/PCA/';
SEMCDataDirTemplate = '/home/netastern/PCA/HPD_dicoms/%d_MESE_TE13_slce_thickness_%d_res_%d_no_grappa/'; % DICOM FOLDER
results_file_prefix_template = 'HPD_Phantom_sl_%d_res_%d';

fit_code_root_folder = '/home/netastern/Siemens/EMC_T2_FIT/';
fit_B1_flag = 1;
mask_th = 0.02;
exp_fit_SEMC = 0;
opts.PD          = 1;
opts.T2          = 1;
opts.dcm         = 1;
opts.nii         = 0;
opts.Siemens_dir = [];

for curr_comb_idx = 1:length(combinations)
	curr_comb = combinations{curr_comb_idx};
	slice_thickness = curr_comb{1};
	resolution = curr_comb{2};
	ws = curr_comb{3};
	img_type = curr_comb{4}; % after_complex_PCA\after_PCA\org_complex\org
	
	fld_idx = get_dcm_folder_idx(slice_thickness, resolution, dicom_folder_mapping);
	SEMCDataDir = sprintf(SEMCDataDirTemplate,fld_idx,slice_thickness,resolution);
	results_file_prefix = sprintf(results_file_prefix_template, slice_thickness, resolution);
	
	if strcmp(img_type,'org_complex')
		img_path = [db_data_root_folder sprintf('unnormalized_org_complex_img_slice_thickness_%d_res_%d', slice_thickness, resolution)];
		results_file_prefix = [results_file_prefix '_org'];
	else
		img_path = [db_data_root_folder sprintf('unnormalized_img_after_complex_pca_slice_thickness_%d_res_%d_ws_%d', slice_thickness, resolution, ws)];
		results_file_prefix = [results_file_prefix '_ws_' num2str(ws)];
	end

	im_SEMC = load(img_path);

	if strcmp(img_type,'org')
		im_SEMC = im_SEMC.im_SEMC_norm;
	elseif strcmp(img_type,'org_complex')
		im_SEMC = im_SEMC.unnorm_org_complex;
	elseif (strcmp(img_type,'after_complex_PCA'))
		im_SEMC = im_SEMC.unnorm_img_after_complex_pca;
	else
		im_SEMC = im_SEMC.image_after_pca;
	end

	if ~isa(im_SEMC,'double')
		im_SEMC = double(im_SEMC);
	end
	
	im_SEMC_mSL = [];
	im_SEMC_mSL(:,:,1,:) = im_SEMC;

	EMC_results = fit_semc([], fit_code_root_folder, SEMCDataDir, mask_th, fit_B1_flag,exp_fit_SEMC, opts, im_SEMC_mSL);
	save([db_data_root_folder results_file_prefix '_EMC_results'], 'EMC_results');
	clear im_SEMC_mSL;
	clear EMC_results;
end

function fldidx = get_dcm_folder_idx(slice_thicnkness, res, dic)
	for i=1:size(dic,1)
		if (dic(i,1) == slice_thicnkness) && (dic(i,2) == res)
			fldidx = dic(i,3);
		end
	end
end