function total_mask = get_circle_mask(centers, ROI_radius, org_img)
	mat_size = size(org_img);
	total_mask = zeros(mat_size);
	tubes_num = length(centers);
	theta = 0:pi/20:2*pi;
	fi(org_img);
	
	for roi_idx = 1:tubes_num
		xi = ROI_radius*cos(theta) + centers(1,roi_idx);
		yi = ROI_radius*sin(theta) + centers(2,roi_idx);
		line(xi,yi,'LineWidth',2,'Color',[.8 0 0]);
		roi_mask = poly2mask(xi, yi, mat_size(1), mat_size(2));
		total_mask = total_mask | roi_mask;
	end
end

