function im_SEMC = get_im_array_from_dicom(dicom_path,slice,is_normalize)
	[~,~,im_SEMC_mSl,~] = Read_mSl_Data(dicom_path);
	im_SEMC = squeeze(im_SEMC_mSl(:,:,slice,:));
	
	if (is_normalize)
		im_SEMC = normalize_SEMC(im_SEMC);
	end
end

