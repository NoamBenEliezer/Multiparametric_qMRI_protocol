clear; 

T2_base_path='.../T2_fit_BrainAtlas/Brain_Atlas';


%% Run all volunteers
dir_list=dir(T2_base_path);
count=0;
for vol_idx=1:length(dir_list)
if dir_list(vol_idx).name(1)=='V'
    count=count+1;
        Volunteer_list{count}=dir_list(vol_idx).name;
end
end

for vol_idx=1:length(Volunteer_list)
vol_ID=Volunteer_list{vol_idx};%'V006';
vol_path = [T2_base_path filesep vol_ID]; % Volunteer main folder

vol_dir=dir(vol_path);
for i=1:length (vol_dir)
    if (length(vol_dir(i).name)>2)
     if strcmp(vol_dir(i).name(1:3),'DAT')
         mat_name=vol_dir(i).name;
     elseif ~strcmp(vol_dir(i).name(1:4),'meas')
         org_DCM_path=vol_dir(i).name;
      end
    end    
end

result_path = [vol_path filesep 'den_DCM']; %Where to save new DCM
mkdir(result_path);

org_DCM_path=[vol_path filesep org_DCM_path];
org_DCM_dir=dir(org_DCM_path);

org_dcm_file_template=org_DCM_dir(5).name;
num_loc=find(org_dcm_file_template=='_');
num_loc=num_loc(end);
org_dcm_file_template=[org_dcm_file_template(1:num_loc) '%d.dcm'];

% result_path = [result_path 'T2_star_maps']; % Where is the .mat from the apply script
% org_dcm_file_template = 'T2_star_map_V002_%d.dcm'; % where is the DICOM info
org_dcm_path_template = [org_DCM_path filesep org_dcm_file_template];

load([vol_path filesep mat_name]);
slices = size(result_3d_mat_den,1);
echoes = size(result_3d_mat_den,4);

for s=1:slices
	for e = 1:echoes
		dcm_idx = (e - 1)*slices + s;
		di = dicominfo(sprintf(org_dcm_path_template,dcm_idx));
		den_img = squeeze(result_3d_mat_den(s,:,:,e));
		curr_save_path = [result_path filesep sprintf('T2_denDCM_%s_TE%d_sl%d_DCMidx_%d.dcm',vol_ID,e*12,s,dcm_idx)];
		dicomwrite(den_img,curr_save_path,di,'WritePrivate',1);
	end
end
end