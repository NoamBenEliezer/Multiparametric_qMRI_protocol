clear; 

T2_base_path='.../Segmentations_FS/Brain_Atlas';
main_org_DCM_path='.../T2_fit_BrainAtlas/Brain_Atlas';

%% Run all volunteers
dir_list=dir(T2_base_path);
count=0;
for vol_idx=1:length(dir_list)
if dir_list(vol_idx).name(1)=='V'
    count=count+1;
        Volunteer_list{count}=dir_list(vol_idx).name;
end
end

for vol_idx=1:length(Volunteer_list)
vol_ID=Volunteer_list{vol_idx}; %e.g., 'V002'
vol_path = [T2_base_path filesep vol_ID]; % Volunteer main folder

vol_dir=dir(vol_path);
% for i=1:length (vol_dir)
%     if (length(vol_dir(i).name)>2)
%      if strcmp(vol_dir(i).name(1:3),'DAT')
%          mat_name=vol_dir(i).name;
%      elseif ~strcmp(vol_dir(i).name(1:4),'meas')
%          org_DCM_path=vol_dir(i).name;
%       end
%     end    
% end

result_path = [vol_path filesep 'qT2']; %Where to save new DCM
% mkdir(result_path);
mat_name=sprintf('%s_EMC_results.mat',vol_ID);

org_DCM_path=[main_org_DCM_path filesep sprintf('%s',vol_ID) filesep 'den_DCM'];
org_DCM_dir=dir(org_DCM_path);

for i=1:length(org_DCM_dir)
    if org_DCM_dir(i).name(1)=='.'
        continue;
    end 
if (org_DCM_dir(i).name(end-5:end)=='_1.dcm')
    DCM_tmplate=org_DCM_dir(i).name;
end
end

org_dcm_file_template=DCM_tmplate;
num_loc=find(org_dcm_file_template=='_');
num_loc=num_loc(end);
org_dcm_file_template=[org_dcm_file_template(1:num_loc) '%d.dcm'];

num_loc=strfind(org_dcm_file_template,'sl');
num_loc=num_loc+2;
% tmp_org_dcm_file_template=org_dcm_file_template;
org_dcm_file_template=[org_dcm_file_template(1:num_loc-1) '%d_DCMidx_%d.dcm'];


% result_path = [result_path 'T2_star_maps']; % Where is the .mat from the apply script
% org_dcm_file_template = 'T2_star_map_V002_%d.dcm'; % where is the DICOM info
org_dcm_path_template = [org_DCM_path filesep org_dcm_file_template];

load([result_path filesep mat_name]);
slices = length(EMC_results);
for sl_idx=1:slices
T2_maps{sl_idx}=EMC_results(sl_idx).T2map_SEMC_masked*1e3;
end
% echoes = size(result_3d_mat_den,4);

for s=1:slices
% 	for e = 1:echoes
		di = dicominfo(sprintf(org_dcm_path_template,s,s));
		den_img = uint16(T2_maps{s});
		curr_save_path = [result_path filesep sprintf('T2map_den_%s_sl_%d.dcm',vol_ID,s)];
		dicomwrite(den_img,curr_save_path,di,'WritePrivate',1);
% 	end
end
end