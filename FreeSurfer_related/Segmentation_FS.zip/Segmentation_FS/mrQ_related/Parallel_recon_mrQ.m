
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% recon + register + segmentation %%%%
%%%%     mrQ data - DR, Oct 2021     %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all; clc

% T1w_Nii_scaling %T1w * 1000

addpath(genpath('.../Segmentations_FS'));
BA_dir='.../mrQ-master/DATA/Brain_atlas';
MultThr_num = 8;

subjects_dir=dir(BA_dir);
subj_count=0;
for i=1:length (subjects_dir)
    
    if subjects_dir(i).name(1)=='.'
        continue;
    end
    subj_count=subj_count+1;
    subjects_list{1, subj_count}=subjects_dir(i).name;
    scan_dir=dir([BA_dir filesep subjects_list{1, subj_count}]);
    
end

count_undone=0;
list_undone=[];
for i=1:length(subjects_list)
    Cur_Sbj_dir= [BA_dir filesep subjects_list{1, i}];
if ~exist([Cur_Sbj_dir filesep 'Segmentation' filesep 'qT1_segments.mgz'])
    count_undone=count_undone+1;
    list_undone(count_undone)=i;
    subjects_list{1, i}
end
end

% parfor SubjectIdx=1:length(list_undone)
       for SubjectIdx=1:length(list_undone)
    list_undone(SubjectIdx)
    Cur_Sbj_dir= [BA_dir filesep subjects_list{1, list_undone(SubjectIdx)}];
    %     Loc_T1w_dir = [subjects_list{2, SubjectIdx} filesep subjects_list{3, SubjectIdx}];
%     if exist([Cur_Sbj_dir filesep 'Segmentation' filesep 'qT1_segments.mgz'])
%         continue;
%     end
    Loc_T1w = 'Analysis/mrQ/OutPutFiles_1/T1w';
%     if length (dir(Cur_Sbj_dir))<10
        Recon_qT1_BrainAtlas(Cur_Sbj_dir, Loc_T1w, MultThr_num);
%     end
    
end
