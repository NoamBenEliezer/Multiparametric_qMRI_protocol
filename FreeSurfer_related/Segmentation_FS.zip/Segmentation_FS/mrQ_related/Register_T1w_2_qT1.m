%% Examplary script 2: command is more clear


%% Script

% % recon-all
Loc_Seg_flr = '00_reconall_qT1';
MultThr_num = 8;

% % Rigid registration

tmp_flr = 'Segmentation';
Cur_Sbj_dir = '/home/noambe/Public/mrQ-master/DATA/Brain_atlas/V002'; % % directory of patient (where all his scans are)
Loc_org_T1w_mgz_dir = '00_reconall_qT1/mri/orig/001.mgz'; % % original T1w .mgz file
Loc_LUT_mgz_dir = '00_reconall_qT1/mri/aparc+aseg.mgz';
Loc_qT1_RegMat_dir = [tmp_flr filesep 'Rec_2_org.dat']; % % intermediate registration transform file
Inv_reg_flg = 1;
Loc_qT1_Reg_dir = [tmp_flr filesep 'qT1_segments.mgz']; % % output .mgz file after registration

% % Create temporary folder for output
tmp_dir = [Cur_Sbj_dir filesep tmp_flr];
mkdir(tmp_dir)

% % Command that calls scripts
FS_shell_cmd = [ ...
    'export FREESURFER_HOME=/usr/local/freesurfer'               newline... % % set freesurfer commands directories
    'source $FREESURFER_HOME/SetUpFreeSurfer.sh'                 newline... % % run a script that configures freesurfer
    'export SUBJECTS_DIR=' Cur_Sbj_dir                           newline... % % set directory of current patient
    'cd $SUBJECTS_DIR'                                           newline... % % change directory to current subject
    'bbregister'                                                        ...
                ' --s ' Loc_Seg_flr                                     ...
                ' --mov ' Loc_org_T1w_mgz_dir                                   ...
                '       --reg ' Loc_qT1_RegMat_dir                      ...
                '       --init-header --t1'                      newline... % % calculate registratiom
    'mri_vol2vol'                                                       ...
                ' --mov ' Loc_org_T1w_mgz_dir                               ... % % perform registration
                '     --targ ' Loc_Seg_flr '/mri/aparc+aseg.mgz'        ...
                ' --interp nearest'                                     ...
                '     --o ' Loc_qT1_Reg_dir                             ...
                '     --reg ' Loc_qT1_RegMat_dir                        ... 
                '     --no-save-reg'                                    ...
    ];
if Inv_reg_flg
    FS_shell_cmd = [FS_shell_cmd ' --inv' newline];
else
    FS_shell_cmd = [FS_shell_cmd newline];
end
                        
%% execute & return exit status

[stat, cmdout] = system(FS_shell_cmd);
% disp(stat) % % 0 = success, ~0 = Error
% disp(cmdout); % % Command output

%% load .mgz

% % % Add freesurfer matlab functions to path
% FS_mtl_Fld  = '.../freesurfer_MATLAB_scripts';
% addpath(FS_mtl_Fld)
% 
% % % Set directories
% T1w_dir = [Cur_Sbj_dir filesep Loc_Seg_flr filesep 'mri/T1.mgz'];
% T2s_dir = [Cur_Sbj_dir filesep Loc_T2s_Reg_dir];
% % qT2_dir = [Cur_Sbj_dir filesep Loc_qT2_Reg_dir];
% T1w_vol = load_mgh(T1w_dir);
% T2s_vol = load_mgh(T2s_dir);
% 
% T1w_vol = permute(T1w_vol, [2, 1, 3]);
% T2s_vol = permute(T2s_vol, [2, 1, 3]);
