clear all; clc

mrQ_data_dir='.../mrQ-master/DATA/Brain_atlas';
MultThr_num = 2;

subjects_dir=dir(mrQ_data_dir);
subj_count=0;
for i=1:length (subjects_dir)
    
    if subjects_dir(i).name(1)=='.'
        continue;
    end
    subj_count=subj_count+1;
    subjects_list{1, subj_count}=subjects_dir(i).name;
    scan_dir=dir([mrQ_data_dir filesep subjects_list{1, subj_count}]);
    
end


       for SubjectIdx=1:length(subjects_list)
    
    Cur_Sbj_dir= [mrQ_data_dir filesep subjects_list{1, SubjectIdx}];

    Loc_T1w = 'Analysis/mrQ/OutPutFiles_1/T1w';

Loc_T1w_dir = [Loc_T1w '/T1w.nii.gz']; % % input dicom file

%% Before recon-all: rescale nii file
Nii_file=niftiread([Cur_Sbj_dir filesep Loc_T1w_dir]);
% Nii_file=fopen([Cur_Sbj_dir filesep Loc_T1w_dir]);
Nii_file=Nii_file*1e3;
Nii_info=niftiinfo([Cur_Sbj_dir filesep Loc_T1w_dir]);
tmp_t1w_loc=['Analysis/mrQ/OutPutFiles_1/T1w' filesep 'tmp_T1w'];
niftiwrite(Nii_file,[Cur_Sbj_dir filesep tmp_t1w_loc],Nii_info);


end