function h = vec(H)
% h = vec(H)
% 
% Vectorize matrix.
%
% H: Matrix
%
% $Revision: 1.1.2.2 $  $Date: 2013/02/23 21:08:11 $
% Original Author: Jorge Luis Bernal Rusiel 
% CVS Revision Info:
%    $Author: nicks $
%    $Date: 2013/02/23 21:08:11 $
%    $Revision: 1.1.2.2 $
%
    
h = H(:);
   